import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { b as Gift, i as Users, l as Scale, m as Package, s as Ticket, u as Recycle, w as ArrowRight, x as FlaskConical } from "./_libs/lucide-react.mjs";
import { s as cn } from "./_ssr/session-DydgTsTx.mjs";
import { b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as Surface, t as PageHeader } from "./_ssr/plant-shell-BIp0kmVK.mjs";
import { a as formatEkp, i as formatDateTime, l as ticketCode, o as formatGrams, s as formatKg } from "./_ssr/format-DXO4Tf2J.mjs";
import { r as getDashboard } from "./_ssr/api-Bh6zuGwc.mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_plant.panel-BO7Xxj2j.js
var import_jsx_runtime = require_jsx_runtime();
function PanelPage() {
	const { data, isLoading, error } = useQuery({
		queryKey: ["dashboard"],
		queryFn: () => getDashboard()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "RF-02 · Menú operativo",
			title: "Panel principal",
			description: "Vista consolidada de acopio RAEE, EkoPuntos y canjes STEM de la planta San José."
		}),
		error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger",
			children: "No se pudo cargar el tablero. Reintentá en unos segundos."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "RAEE reciclado",
					value: data ? formatKg(data.totalKg) : "—",
					hint: "Peso acopiado en planta",
					icon: Scale
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "EkoPuntos emitidos",
					value: data ? formatEkp(data.totalEkpIssued) : "—",
					hint: "Acreditados automáticamente",
					icon: Recycle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "Canjes pendientes",
					value: data ? String(data.pendingRedemptions) : "—",
					hint: "Retiro en ventanilla",
					icon: Gift
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
					label: "Clientes activos",
					value: data ? String(data.activeClients) : "—",
					hint: "Escuelas y vecinos",
					icon: Users
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-3 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "lg:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-display text-lg font-semibold",
					children: "Accesos rápidos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/recepcion",
							rf: "RF-07",
							title: "Recepción y acopio",
							copy: "Registrar hardware obsoleto, pesaje y acreditación inmediata de EKP.",
							icon: Recycle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/canjes",
							rf: "RF-08 · RF-09",
							title: "Procesar canjes STEM",
							copy: "Entregar kits y sensores, marcar retiro o cancelar con motivo.",
							icon: Gift
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/catalogo",
							rf: "RF-05 · RF-06 · RF-11",
							title: "Inventario de premios",
							copy: "Alta de artículos, costos en EKP y baja de productos discontinuados.",
							icon: Package
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/clientes",
							rf: "RF-03 · RF-04 · RF-13",
							title: "Clientes y saldos",
							copy: "Escuelas técnicas, vecinos y consulta transparente de EkoPuntos.",
							icon: Users
						})
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlaskConical, { className: "size-4 text-leaf" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold",
						children: "Metales críticos"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-4 text-sm text-muted",
					children: "Estimación contable previa al despacho a fundiciones especializadas."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metal, {
							name: "Cobre",
							value: data ? formatKg(data.copperKg) : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metal, {
							name: "Silicio",
							value: data ? formatKg(data.siliconKg) : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metal, {
							name: "Oro",
							value: data ? formatGrams(data.goldG) : "—"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted",
					children: data ? `${data.stemUnitsDelivered} componentes STEM ya entregados a escuelas.` : isLoading ? "Calculando inventario…" : ""
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-3 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Últimas recepciones"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/recepcion",
					className: "text-sm font-medium text-leaf-dark",
					children: "Ir a ventanilla"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [(data?.recentDeliveries ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Todavía no hay ingresos registrados."
				}), data?.recentDeliveries.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3 border-b border-line pb-3 last:border-0 last:pb-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: item.clientName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							item.hardwareName,
							" · ",
							formatKg(item.weightKg)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium tabular-nums text-leaf-dark",
							children: formatEkp(item.ekpGenerated)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: formatDateTime(item.createdAt)
						})]
					})]
				}, item.id))]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Tiques recientes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/tiques",
					className: "inline-flex items-center gap-1 text-sm font-medium text-leaf-dark",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ticket, { className: "size-3.5" }), "Ver todos"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [(data?.recentTickets ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Los comprobantes aparecerán al registrar operaciones."
				}), data?.recentTickets.map((ticket) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3 border-b border-line pb-3 last:border-0 last:pb-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tabular-nums text-muted",
						children: ticketCode(ticket.id)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: ticket.summary
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tabular-nums",
						children: formatEkp(ticket.ekpAmount)
					})]
				}, ticket.id))]
			})] })]
		})
	] });
}
function Kpi({ label, value, hint, icon: Icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
		className: "p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 text-leaf" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl font-semibold tabular-nums tracking-tight",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: hint
			})
		]
	});
}
function Quick({ to, rf, title, copy, icon: Icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("group flex gap-3 rounded-lg border border-line bg-paper p-4 transition-colors hover:border-leaf/40 hover:bg-mist"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-10 shrink-0 place-items-center rounded-md bg-leaf/12 text-leaf-dark",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-muted transition-transform group-hover:translate-x-0.5" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block text-[0.65rem] uppercase tracking-wider text-muted",
					children: rf
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-sm text-muted",
					children: copy
				})
			]
		})]
	});
}
function Metal({ name, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center justify-between border-b border-line pb-2 last:border-0 last:pb-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm",
			children: name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { PanelPage as component };
