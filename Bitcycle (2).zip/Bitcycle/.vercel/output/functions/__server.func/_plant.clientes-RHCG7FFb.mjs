import { o as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { c as Search, f as Plus } from "./_libs/lucide-react.mjs";
import { n as Button } from "./_ssr/session-DydgTsTx.mjs";
import { r as Surface, t as PageHeader } from "./_ssr/plant-shell-BIp0kmVK.mjs";
import { a as formatEkp, r as clientCode } from "./_ssr/format-DXO4Tf2J.mjs";
import { t as Badge } from "./_ssr/badge-CjwtrIb1.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./_ssr/dialog-Badtkvih.mjs";
import { t as Input } from "./_ssr/input-_tkuuvhL.mjs";
import { t as Label } from "./_ssr/label-ajXKc8VR.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-jPY41byw.mjs";
import { a as listClients, f as setClientStatus, n as createClient } from "./_ssr/api-Bh6zuGwc.mjs";
import { t as errorMessage } from "./_ssr/errors-Caz7GCy2.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_plant.clientes-RHCG7FFb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ClientesPage() {
	const queryClient = useQueryClient();
	const clients = useQuery({
		queryKey: ["clients"],
		queryFn: () => listClients()
	});
	const [query, setQuery] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [dniCuit, setDniCuit] = (0, import_react.useState)("");
	const [clientType, setClientType] = (0, import_react.useState)("escuela");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return (clients.data ?? []).filter((client) => {
			if (!q) return true;
			return [
				client.name,
				client.dniCuit,
				client.phone,
				client.address
			].join(" ").toLowerCase().includes(q);
		});
	}, [clients.data, query]);
	const createMutation = useMutation({
		mutationFn: () => createClient({ data: {
			name,
			dniCuit,
			clientType,
			phone,
			address,
			email
		} }),
		onSuccess: () => {
			toast.success("Cliente registrado.");
			setOpen(false);
			setName("");
			setDniCuit("");
			setPhone("");
			setAddress("");
			setEmail("");
			queryClient.invalidateQueries({ queryKey: ["clients"] });
			queryClient.invalidateQueries({ queryKey: ["dashboard"] });
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const statusMutation = useMutation({
		mutationFn: (input) => setClientStatus({ data: input }),
		onSuccess: (client) => {
			toast.success(client.status === "activo" ? "Cliente reactivado." : "Cliente dado de baja.");
			queryClient.invalidateQueries({ queryKey: ["clients"] });
			queryClient.invalidateQueries({ queryKey: ["dashboard"] });
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "RF-03 · RF-04 · RF-13",
			title: "Clientes y saldos",
			description: "Cuentas de escuelas técnicas y vecinos. El saldo de EkoPuntos se muestra con total transparencia.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Registrar cliente"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, {
			className: "mb-4 p-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "pl-10",
					placeholder: "Buscar por nombre, CUIT, teléfono o dirección",
					value: query,
					onChange: (e) => setQuery(e.target.value)
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, {
			className: "overflow-hidden p-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[52rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-mist text-xs uppercase tracking-wider text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Cliente / Institución"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "DNI / CUIT"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Teléfono y dirección"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Saldo EkoPuntos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Estado"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Acción"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 7,
						className: "px-4 py-10 text-center text-muted",
						children: "No hay clientes con ese criterio."
					}) }), filtered.map((client) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums text-muted",
								children: clientCode(client.id)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: client.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: client.clientType === "escuela" ? "Escuela técnica" : "Particular / vecino"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: client.dniCuit
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: client.phone || "—" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: client.address || "Sin dirección"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-medium tabular-nums text-leaf-dark",
								children: formatEkp(client.ekopuntos)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: client.status === "activo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "leaf",
									children: "Activo"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: "Inactivo"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: client.status === "activo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									className: "text-danger",
									onClick: () => statusMutation.mutate({
										id: client.id,
										status: "inactivo"
									}),
									children: "Dar de baja"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => statusMutation.mutate({
										id: client.id,
										status: "activo"
									}),
									children: "Reactivar"
								})
							})
						]
					}, client.id))] })]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Registrar nuevo cliente / escuela" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "razon",
								children: "Nombre / razón social"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "razon",
								placeholder: "Ej. Escuela Técnica N°1",
								value: name,
								onChange: (e) => setName(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "cuit",
									children: "DNI / CUIT"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "cuit",
									placeholder: "30-12345678-9",
									value: dniCuit,
									onChange: (e) => setDniCuit(e.target.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Tipo de cliente" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: clientType,
									onValueChange: (value) => setClientType(value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "escuela",
										children: "Escuela técnica"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "particular",
										children: "Particular / vecino"
									})] })]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "tel",
									children: "Teléfono"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "tel",
									placeholder: "3838400000",
									value: phone,
									onChange: (e) => setPhone(e.target.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "dir",
									children: "Dirección"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "dir",
									placeholder: "Av. Principal San José",
									value: address,
									onChange: (e) => setAddress(e.target.value)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "mail",
								children: "Correo (opcional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "mail",
								type: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value)
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setOpen(false),
					children: "Cancelar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: name.trim().length < 3 || dniCuit.trim().length < 7 || createMutation.isPending,
					onClick: () => createMutation.mutate(),
					children: "Guardar cliente"
				})] })
			] })
		})
	] });
}
//#endregion
export { ClientesPage as component };
