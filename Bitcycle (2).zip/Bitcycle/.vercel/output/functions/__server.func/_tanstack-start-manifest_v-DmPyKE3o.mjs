//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DmPyKE3o.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/_plant"],
		preloads: [
			"/assets/index-BIHvI6Hr.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/createLucideIcon-B41BnYfe.js",
			"/assets/query-CMuSn_U0.js",
			"/assets/link-BHo55Z8y.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BIHvI6Hr.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CG7T1-3X.js",
			"/assets/dist-BcTcR8RB.js",
			"/assets/session-rsoMUVF-.js",
			"/assets/input-Cxf2-HLM.js",
			"/assets/label-CrUX_C5c.js"
		]
	},
	"/_plant": {
		filePath: "/workspace/src/routes/_plant.tsx",
		children: [
			"/_plant/canjes",
			"/_plant/catalogo",
			"/_plant/clientes",
			"/_plant/panel",
			"/_plant/recepcion",
			"/_plant/tiques"
		],
		preloads: ["/assets/_plant-CJocfnZu.js", "/assets/plant-shell-DQ5Sn5M4.js"]
	},
	"/_plant/canjes": {
		filePath: "/workspace/src/routes/_plant.canjes.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.canjes-BINBBU1U.js",
			"/assets/format-BXJDcpI-.js",
			"/assets/dist-BcTcR8RB.js",
			"/assets/select-Mp3JeEJh.js",
			"/assets/session-rsoMUVF-.js",
			"/assets/badge-BpDYOx8A.js",
			"/assets/errors-Bola9MiG.js",
			"/assets/dialog-DoBx38hz.js",
			"/assets/input-Cxf2-HLM.js",
			"/assets/label-CrUX_C5c.js",
			"/assets/textarea-BxBF5NpG.js"
		]
	},
	"/_plant/catalogo": {
		filePath: "/workspace/src/routes/_plant.catalogo.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.catalogo-zJqsb1mm.js",
			"/assets/format-BXJDcpI-.js",
			"/assets/session-rsoMUVF-.js",
			"/assets/badge-BpDYOx8A.js",
			"/assets/errors-Bola9MiG.js",
			"/assets/dialog-DoBx38hz.js",
			"/assets/input-Cxf2-HLM.js",
			"/assets/label-CrUX_C5c.js"
		]
	},
	"/_plant/clientes": {
		filePath: "/workspace/src/routes/_plant.clientes.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.clientes-B-a3FAV4.js",
			"/assets/format-BXJDcpI-.js",
			"/assets/select-Mp3JeEJh.js",
			"/assets/session-rsoMUVF-.js",
			"/assets/badge-BpDYOx8A.js",
			"/assets/search-ChW6Rn3L.js",
			"/assets/errors-Bola9MiG.js",
			"/assets/dialog-DoBx38hz.js",
			"/assets/input-Cxf2-HLM.js",
			"/assets/label-CrUX_C5c.js"
		]
	},
	"/_plant/panel": {
		filePath: "/workspace/src/routes/_plant.panel.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.panel-Dv1oi139.js",
			"/assets/format-BXJDcpI-.js",
			"/assets/session-rsoMUVF-.js",
			"/assets/scale-CSBDt7wj.js"
		]
	},
	"/_plant/recepcion": {
		filePath: "/workspace/src/routes/_plant.recepcion.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.recepcion-BWjNRBdf.js",
			"/assets/format-BXJDcpI-.js",
			"/assets/select-Mp3JeEJh.js",
			"/assets/session-rsoMUVF-.js",
			"/assets/scale-CSBDt7wj.js",
			"/assets/errors-Bola9MiG.js",
			"/assets/dialog-DoBx38hz.js",
			"/assets/input-Cxf2-HLM.js",
			"/assets/label-CrUX_C5c.js",
			"/assets/textarea-BxBF5NpG.js",
			"/assets/ticket-card-l7VaR3zV.js"
		]
	},
	"/_plant/tiques": {
		filePath: "/workspace/src/routes/_plant.tiques.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.tiques-DqkKwtWG.js",
			"/assets/format-BXJDcpI-.js",
			"/assets/session-rsoMUVF-.js",
			"/assets/search-ChW6Rn3L.js",
			"/assets/dialog-DoBx38hz.js",
			"/assets/input-Cxf2-HLM.js",
			"/assets/ticket-card-l7VaR3zV.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
