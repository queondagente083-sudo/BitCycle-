import { o as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { f as Plus, p as Pencil } from "./_libs/lucide-react.mjs";
import { n as Button } from "./_ssr/session-DydgTsTx.mjs";
import { r as Surface, t as PageHeader } from "./_ssr/plant-shell-BIp0kmVK.mjs";
import { a as formatEkp, t as articleCode } from "./_ssr/format-DXO4Tf2J.mjs";
import { t as Badge } from "./_ssr/badge-CjwtrIb1.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./_ssr/dialog-Badtkvih.mjs";
import { t as Input } from "./_ssr/input-_tkuuvhL.mjs";
import { t as Label } from "./_ssr/label-ajXKc8VR.mjs";
import { d as setArticleActive, i as listArticles, p as updateArticleCost, t as createArticle } from "./_ssr/api-Bh6zuGwc.mjs";
import { t as errorMessage } from "./_ssr/errors-Caz7GCy2.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_plant.catalogo-C1NnbHaH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CatalogoPage() {
	const queryClient = useQueryClient();
	const articles = useQuery({
		queryKey: ["articles"],
		queryFn: () => listArticles()
	});
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const [description, setDescription] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("Kits Robótica");
	const [cost, setCost] = (0, import_react.useState)("");
	const [stock, setStock] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [newCost, setNewCost] = (0, import_react.useState)("");
	function invalidate() {
		queryClient.invalidateQueries({ queryKey: ["articles"] });
		queryClient.invalidateQueries({ queryKey: ["dashboard"] });
	}
	const createMutation = useMutation({
		mutationFn: () => createArticle({ data: {
			description,
			category,
			costEkp: Number(cost),
			stock: Number(stock)
		} }),
		onSuccess: () => {
			toast.success("Artículo agregado al catálogo.");
			setCreateOpen(false);
			setDescription("");
			setCost("");
			setStock("");
			invalidate();
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const costMutation = useMutation({
		mutationFn: () => updateArticleCost({ data: {
			id: editing.id,
			costEkp: Number(newCost)
		} }),
		onSuccess: () => {
			toast.success("Costo actualizado.");
			setEditing(null);
			invalidate();
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const activeMutation = useMutation({
		mutationFn: (input) => setArticleActive({ data: input }),
		onSuccess: (article) => {
			toast.success(article.active ? "Artículo reactivado." : "Artículo discontinuado.");
			invalidate();
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const list = articles.data ?? [];
	const available = list.filter((a) => a.active).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "RF-05 · RF-06 · RF-11 · RF-12",
			title: "Catálogo y stock",
			description: "Kits de robótica, sensores y actuadores del depósito de San José. Actualizá costos sin tocar el resto del inventario.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setCreateOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Agregar artículo"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Ítems activos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-semibold tabular-nums",
						children: available
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Unidades en depósito"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-semibold tabular-nums",
						children: list.filter((a) => a.active).reduce((sum, a) => sum + a.stock, 0)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Discontinuados"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-semibold tabular-nums",
						children: list.filter((a) => !a.active).length
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: list.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-start justify-between gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: article.category }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: article.active ? "leaf" : "outline",
									children: article.active ? "Disponible" : "Discontinuado"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-semibold leading-tight",
								children: article.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs tabular-nums text-muted",
								children: ["ID producto: ", articleCode(article.id)]
							})
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded-md bg-mist px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wider text-muted",
							children: "Costo canje"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-semibold tabular-nums text-leaf-dark",
							children: formatEkp(article.costEkp)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => {
								setEditing(article);
								setNewCost(String(article.costEkp));
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" }), "Editar costo"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [
								"Stock actual:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
									className: "tabular-nums",
									children: [article.stock, " unidades"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							className: article.active ? "text-danger" : "text-leaf-dark",
							onClick: () => activeMutation.mutate({
								id: article.id,
								active: !article.active
							}),
							children: article.active ? "Discontinuar" : "Reactivar"
						})]
					})
				]
			}, article.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: createOpen,
			onOpenChange: setCreateOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Agregar artículo STEM" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "desc",
							children: "Descripción"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "desc",
							placeholder: "Ej. Kit Arduino Uno R3 con sensores",
							value: description,
							onChange: (e) => setDescription(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "cat",
									children: "Categoría"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "cat",
									value: category,
									onChange: (e) => setCategory(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "cost",
									children: "Costo EKP"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "cost",
									inputMode: "numeric",
									value: cost,
									onChange: (e) => setCost(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "stock",
									children: "Stock inicial"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "stock",
									inputMode: "numeric",
									value: stock,
									onChange: (e) => setStock(e.target.value)
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setCreateOpen(false),
					children: "Cancelar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !description.trim() || Number(cost) <= 0 || createMutation.isPending,
					onClick: () => createMutation.mutate(),
					children: "Guardar artículo"
				})] })
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!editing,
			onOpenChange: (open) => !open && setEditing(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Modificar costo EKP" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: editing?.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "newcost",
						children: "Nuevo costo en EkoPuntos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "newcost",
						inputMode: "numeric",
						value: newCost,
						onChange: (e) => setNewCost(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setEditing(null),
					children: "Cancelar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: Number(newCost) <= 0 || costMutation.isPending,
					onClick: () => costMutation.mutate(),
					children: "Actualizar costo"
				})] })
			] })
		})
	] });
}
//#endregion
export { CatalogoPage as component };
