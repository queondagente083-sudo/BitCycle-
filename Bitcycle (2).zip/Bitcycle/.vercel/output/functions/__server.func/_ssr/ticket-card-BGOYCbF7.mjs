import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { u as Recycle } from "../_libs/lucide-react.mjs";
import { s as cn } from "./session-DydgTsTx.mjs";
import { a as formatEkp, i as formatDateTime, l as ticketCode } from "./format-DXO4Tf2J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ticket-card-BGOYCbF7.js
var import_jsx_runtime = require_jsx_runtime();
function markCells(code) {
	const cells = [];
	for (let i = 0; i < 49; i += 1) {
		const ch = code.charCodeAt(i % code.length) + i * 13;
		cells.push(ch % 3 !== 0);
	}
	return cells;
}
function TicketFace({ ticket, className }) {
	const code = ticketCode(ticket.id);
	const cells = markCells(code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("overflow-hidden rounded-lg border border-line bg-elevated text-ink", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between bg-forest px-4 py-3 text-elevated",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recycle, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-base font-semibold",
						children: "BitCycle"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs tabular-nums tracking-wide",
					children: code
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 p-4 sm:grid-cols-[1fr_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-wider text-muted",
							children: "Cliente"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-medium",
							children: ticket.clientName
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-wider text-muted",
							children: "Operación"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: ticket.operationType === "entrega" ? "Acreditación RAEE" : "Canje premio STEM" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-wider text-muted",
							children: "Detalle"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: ticket.summary })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-muted",
								children: "Monto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display text-2xl font-semibold tabular-nums text-leaf-dark",
								children: formatEkp(ticket.ekpAmount)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: formatDateTime(ticket.createdAt)
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "grid size-24 shrink-0 grid-cols-7 gap-px self-center rounded-sm bg-ink p-1",
					children: cells.map((on, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: on ? "bg-elevated" : "bg-ink" }, i))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-t border-line px-4 py-2 text-[0.7rem] text-muted",
				children: "Planta San José · Santa María, Catamarca · Comprobante interno no fiscal"
			})
		]
	});
}
//#endregion
export { TicketFace as t };
