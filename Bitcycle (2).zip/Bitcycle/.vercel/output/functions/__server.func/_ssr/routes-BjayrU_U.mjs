import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as CheckboxIndicator, p as require_jsx_runtime, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { C as Check, a as UserRound, g as MapPin, n as Wifi, u as Recycle, v as Lock } from "../_libs/lucide-react.mjs";
import { a as authenticate, c as loadSession, n as Button, r as DEMO_OPERATORS, s as cn, t as BrandMark } from "./session-DydgTsTx.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Input } from "./input-_tkuuvhL.mjs";
import { t as Label } from "./label-ajXKc8VR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BjayrU_U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid size-5 shrink-0 place-items-center rounded-xs border border-line bg-elevated shadow-sm data-[state=checked]:border-leaf data-[state=checked]:bg-leaf data-[state=checked]:text-elevated", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: "grid place-items-center text-current",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
			className: "size-3.5",
			strokeWidth: 3
		})
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
function LoginPage() {
	const navigate = useNavigate();
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [remember, setRemember] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (loadSession()) navigate({ to: "/panel" });
	}, [navigate]);
	function onSubmit(event) {
		event.preventDefault();
		setError("");
		if (!authenticate(username, password, remember)) {
			setError("Usuario o contraseña incorrectos.");
			return;
		}
		navigate({ to: "/panel" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh overflow-hidden bg-forest-deep text-elevated",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ValleyBackdrop, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "relative z-10 mx-auto flex min-h-dvh max-w-md flex-col justify-center px-4 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "rounded-xl border border-elevated/10 bg-elevated p-6 text-ink shadow-card sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6 flex flex-col items-center text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, {
									className: "mb-4 size-14 rounded-lg bg-leaf text-elevated",
									iconClassName: "size-7"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "font-display text-3xl font-semibold tracking-tight",
									children: "BitCycle"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: "Planta de Reciclaje RAEE y Gestión STEM"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "username",
										children: "Usuario operador"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "username",
											autoComplete: "username",
											className: "pl-10",
											placeholder: "operador1",
											value: username,
											onChange: (e) => setUsername(e.target.value)
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "password",
										children: "Contraseña"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "password",
											type: "password",
											autoComplete: "current-password",
											className: "pl-10",
											placeholder: "••••••••",
											value: password,
											onChange: (e) => setPassword(e.target.value)
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2 text-sm text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
											checked: remember,
											onCheckedChange: (value) => setRemember(value === true)
										}), "Recordar sesión local"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 text-xs font-medium text-leaf-dark",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { className: "size-3.5" }), "Planta en línea"]
									})]
								}),
								error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "rounded-md bg-danger/10 px-3 py-2 text-sm text-danger",
									children: error
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									size: "lg",
									className: "w-full",
									children: "Iniciar sesión operativa"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 rounded-md bg-mist px-3 py-3 text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 font-medium text-ink",
								children: "Acceso de demostración"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1",
								children: DEMO_OPERATORS.map((op) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "text-left hover:text-leaf-dark",
									onClick: () => {
										setUsername(op.username);
										setPassword(op.password);
										setError("");
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium text-ink",
											children: op.username
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [" / ", op.password] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted",
											children: [" — ", op.displayName]
										})
									]
								}) }, op.username))
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 flex items-center justify-center gap-1.5 text-center text-xs text-elevated/70",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }), "San José, Santa María, Catamarca · Reciclaje responsable de RAEE"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 flex items-center justify-center gap-1 text-center text-[0.7rem] text-elevated/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recycle, { className: "size-3" }), "EkoPuntos · Educación STEM · Metales críticos"]
				})
			]
		})]
	});
}
function ValleyBackdrop() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "pointer-events-none absolute inset-0 h-full w-full",
		viewBox: "0 0 1200 900",
		preserveAspectRatio: "xMidYMax slice",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "1200",
				height: "900",
				fill: "#0b221c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "980",
				cy: "120",
				r: "220",
				fill: "#12352c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "180",
				cy: "80",
				r: "160",
				fill: "#12352c",
				opacity: "0.7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M0 540 C180 480 280 620 460 560 C640 500 720 640 900 580 C1040 530 1120 600 1200 560 L1200 900 L0 900 Z",
				fill: "#12352c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M0 620 C220 580 340 700 520 650 C700 600 790 720 980 660 C1100 624 1160 680 1200 650 L1200 900 L0 900 Z",
				fill: "#0f2c24"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M0 730 C160 700 300 780 480 750 C680 714 760 810 980 770 C1100 748 1160 790 1200 770 L1200 900 L0 900 Z",
				fill: "#0c241e"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				opacity: "0.18",
				stroke: "#e4eee8",
				strokeWidth: "1",
				fill: "none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M80 200 h40 m-20 -20 v40 M200 260 h28 m-14 -14 v28" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M1040 260 h36 m-18 -18 v36 M900 180 h24 m-12 -12 v24" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "100",
						cy: "220",
						r: "3",
						fill: "#e4eee8"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "214",
						cy: "260",
						r: "3",
						fill: "#e4eee8"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "1058",
						cy: "260",
						r: "3",
						fill: "#e4eee8"
					})
				]
			})
		]
	});
}
//#endregion
export { LoginPage as component };
