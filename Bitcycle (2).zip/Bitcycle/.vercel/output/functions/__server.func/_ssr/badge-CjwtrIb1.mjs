import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { s as cn } from "./session-DydgTsTx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-CjwtrIb1.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-mist text-ink",
		leaf: "bg-leaf/12 text-leaf-dark",
		forest: "bg-forest text-elevated",
		warn: "bg-warn/12 text-warn",
		danger: "bg-danger/10 text-danger",
		outline: "border border-line text-muted"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Badge as t };
