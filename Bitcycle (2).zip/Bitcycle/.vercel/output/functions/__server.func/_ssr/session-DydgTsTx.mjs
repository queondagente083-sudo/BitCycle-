import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime, u as Slot } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { u as Recycle } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session-DydgTsTx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function BrandMark({ className, iconClassName }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid size-10 place-items-center rounded-md bg-leaf text-elevated", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recycle, {
			className: cn("size-5", iconClassName),
			strokeWidth: 2.2
		})
	});
}
function Wordmark({ inverted = false, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, { className: inverted ? "bg-elevated/12 text-elevated" : void 0 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "leading-tight",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("font-display text-lg font-semibold tracking-tight", inverted ? "text-elevated" : "text-ink"),
				children: "BitCycle"
			}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("text-[0.65rem] font-medium uppercase tracking-[0.16em]", inverted ? "text-elevated/70" : "text-muted"),
				children: "The Green Ledger"
			})]
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[transform,background-color,color,box-shadow,opacity] duration-150 ease-out disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-leaf text-elevated hover:bg-leaf-dark shadow-sm",
			secondary: "bg-elevated text-ink border border-line hover:bg-mist",
			outline: "border border-line bg-transparent text-ink hover:bg-mist",
			ghost: "text-ink hover:bg-mist",
			destructive: "bg-danger text-elevated hover:opacity-90",
			forest: "bg-forest text-elevated hover:bg-forest-deep"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var STORAGE_KEY = "bitcycle-operator-session";
var OPERATORS = [{
	username: "operador1",
	password: "sanjose",
	displayName: "Operador San José",
	role: "operador"
}, {
	username: "admin",
	password: "bitcycle",
	displayName: "Dirección Operativa",
	role: "admin"
}];
var DEMO_OPERATORS = OPERATORS.map(({ username, password, displayName, role }) => ({
	username,
	password,
	displayName,
	role
}));
function store(remembered) {
	if (typeof window === "undefined") return null;
	return remembered ? window.localStorage : window.sessionStorage;
}
function authenticate(username, password, remembered) {
	const match = OPERATORS.find((op) => op.username.toLowerCase() === username.trim().toLowerCase() && op.password === password);
	if (!match) return null;
	const session = {
		username: match.username,
		displayName: match.displayName,
		role: match.role,
		remembered
	};
	persistSession(session);
	return session;
}
function persistSession(session) {
	const target = store(session.remembered);
	if (!target) return;
	window.localStorage.removeItem(STORAGE_KEY);
	window.sessionStorage.removeItem(STORAGE_KEY);
	target.setItem(STORAGE_KEY, JSON.stringify(session));
}
function loadSession() {
	if (typeof window === "undefined") return null;
	const raw = window.localStorage.getItem(STORAGE_KEY) ?? window.sessionStorage.getItem(STORAGE_KEY);
	if (!raw) return null;
	try {
		const parsed = JSON.parse(raw);
		if (!parsed?.username || !parsed?.displayName) return null;
		return parsed;
	} catch {
		return null;
	}
}
function clearSession() {
	if (typeof window === "undefined") return;
	window.localStorage.removeItem(STORAGE_KEY);
	window.sessionStorage.removeItem(STORAGE_KEY);
}
//#endregion
export { authenticate as a, loadSession as c, Wordmark as i, Button as n, clearSession as o, DEMO_OPERATORS as r, cn as s, BrandMark as t };
