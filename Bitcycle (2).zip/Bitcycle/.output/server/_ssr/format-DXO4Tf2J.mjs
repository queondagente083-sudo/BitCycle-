import { n as parseISO, r as format, t as es } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-DXO4Tf2J.js
function formatEkp(value) {
	return `${Math.round(value).toLocaleString("es-AR")} EKP`;
}
function formatKg(value) {
	return `${value.toLocaleString("es-AR", {
		minimumFractionDigits: value % 1 === 0 ? 0 : 1,
		maximumFractionDigits: 2
	})} kg`;
}
function formatGrams(value) {
	return `${value.toLocaleString("es-AR", {
		minimumFractionDigits: 1,
		maximumFractionDigits: 2
	})} g`;
}
function formatDateTime(value) {
	const date = value.includes("T") ? parseISO(value) : new Date(value);
	if (Number.isNaN(date.getTime())) return value;
	return format(date, "d MMM yyyy · HH:mm", { locale: es });
}
function clientCode(id) {
	return `#${String(100 + id)}`;
}
function articleCode(id) {
	return `#${String(500 + id)}`;
}
function ticketCode(id, year = 2026) {
	return `TK-${year}-${String(id).padStart(4, "0")}`;
}
function redemptionCode(id, year = 2026) {
	return `CAN-${year}-${String(id).padStart(3, "0")}`;
}
function asNumber(value) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	const parsed = parseFloat(String(value ?? 0));
	return Number.isFinite(parsed) ? parsed : 0;
}
//#endregion
export { formatEkp as a, redemptionCode as c, formatDateTime as i, ticketCode as l, asNumber as n, formatGrams as o, clientCode as r, formatKg as s, articleCode as t };
