import { t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, n as boolean, r as number, t as _enum } from "../_libs/zod.mjs";
import { t as createSsrRpc } from "./auth-JuGpVpOr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-B6qAg5ds.js
var getDashboard = createServerFn({ method: "GET" }).handler(createSsrRpc("9702758c6fd0cb855b9213cc5e565c91c6cccffe5c6a276226117b92c405025e"));
var listClients = createServerFn({ method: "GET" }).handler(createSsrRpc("ff88e4208d74c8d6e8f24c59d7a770c05fc331196e753cb0b233f3829c8ecf31"));
var listHardwareTypes = createServerFn({ method: "GET" }).handler(createSsrRpc("081c6385a5e54b8eb837ef37f60dab54e7171514c9f46ba1addd9508ec1f5270"));
var listArticles = createServerFn({ method: "GET" }).handler(createSsrRpc("b4066697b38382bf04a4c60e49c48cdc9c70cac7a7de03603f12f3e4f8b44398"));
var listRedemptions = createServerFn({ method: "GET" }).handler(createSsrRpc("881501abbb283835a177bf5e86bd70bff329f31cb64eeee2e01238efc7257941"));
var listTickets = createServerFn({ method: "GET" }).handler(createSsrRpc("0eecd7b100619c350ac0360f2a295b721eb95db0861b002d18f56d509274b6eb"));
var createClient = createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(3, "Ingresá el nombre o razón social").max(50),
	dniCuit: string().trim().min(7, "Ingresá DNI o CUIT").max(15),
	clientType: _enum(["escuela", "particular"]),
	phone: string().trim().max(20).default(""),
	address: string().trim().max(80).default(""),
	email: string().trim().max(80).default("")
})).handler(createSsrRpc("7eb023852fe655719f65fceab286b3c33f755b7831756abde5380ff497030630"));
var setClientStatus = createServerFn({ method: "POST" }).validator(object({
	id: number().int(),
	status: _enum(["activo", "inactivo"])
})).handler(createSsrRpc("5fcbdf5e28c83a9b3541e1af4bbea35894eaafbffa13e6e3cc1855f55472256c"));
var createArticle = createServerFn({ method: "POST" }).validator(object({
	description: string().trim().min(3).max(60),
	category: string().trim().min(3).max(50),
	costEkp: number().int().min(1).max(1e5),
	stock: number().int().min(0).max(999999)
})).handler(createSsrRpc("9dc2e6fabf1fafd82312a2a9a345635d3d183451979f39aec688e9767632e99c"));
var updateArticleCost = createServerFn({ method: "POST" }).validator(object({
	id: number().int(),
	costEkp: number().int().min(1).max(1e5)
})).handler(createSsrRpc("a9d89387b01d16a98626e1d37766dd0a630a9cf521c91bc8dd15ecf6658f102d"));
var setArticleActive = createServerFn({ method: "POST" }).validator(object({
	id: number().int(),
	active: boolean()
})).handler(createSsrRpc("f659632a3871f92df8440c903ba0c178e3d5f78b32dd33b17ca81b708beec679"));
var registerDelivery = createServerFn({ method: "POST" }).validator(object({
	clientId: number().int(),
	hardwareTypeId: number().int(),
	weightKg: number().positive().max(5e3),
	notes: string().trim().max(200).default("")
})).handler(createSsrRpc("befea5f824b33f02c203de8787f92eacad90385c46986ffe8ac44c870eb2db4b"));
var registerRedemption = createServerFn({ method: "POST" }).validator(object({
	clientId: number().int(),
	articleId: number().int(),
	quantity: number().int().min(1).max(99)
})).handler(createSsrRpc("cf70c1d40d5ec961363473c37c4707768ed69cea5a19e964d6c0e8ac33872fe4"));
var updateRedemptionStatus = createServerFn({ method: "POST" }).validator(object({
	id: number().int(),
	status: _enum(["entregado", "cancelado"]),
	cancelReason: string().trim().max(100).optional()
})).handler(createSsrRpc("6ef51b980fd43cd63ee81d3a0412bcd4356fc9b13e7b6bd7c69d8a56577092ac"));
//#endregion
export { listClients as a, listTickets as c, setArticleActive as d, setClientStatus as f, listArticles as i, registerDelivery as l, updateRedemptionStatus as m, createClient as n, listHardwareTypes as o, updateArticleCost as p, getDashboard as r, listRedemptions as s, createArticle as t, registerRedemption as u };
