import { t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, n as boolean, r as number, t as _enum } from "../_libs/zod.mjs";
import { r as requireOperator } from "./auth-JuGpVpOr.mjs";
import { n as asNumber } from "./format-DXO4Tf2J.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DL9WGBOy.js
var _0002_bitcycle_default = "create table if not exists clients (\n  id serial primary key,\n  name text not null,\n  dni_cuit text not null unique,\n  client_type text not null,\n  phone text not null default '',\n  address text not null default '',\n  email text not null default '',\n  ekopuntos integer not null default 0,\n  status text not null default 'activo',\n  deactivated_at timestamptz,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists hardware_types (\n  id serial primary key,\n  name text not null,\n  description text not null default '',\n  ekp_per_kg integer not null,\n  copper_kg_per_kg numeric(6, 3) not null default 0,\n  silicon_kg_per_kg numeric(6, 3) not null default 0,\n  gold_g_per_kg numeric(6, 3) not null default 0\n);\n\ncreate table if not exists articles (\n  id serial primary key,\n  description text not null,\n  category text not null,\n  cost_ekp integer not null,\n  stock integer not null default 0,\n  active boolean not null default true,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists deliveries (\n  id serial primary key,\n  client_id integer not null references clients(id),\n  hardware_type_id integer not null references hardware_types(id),\n  weight_kg numeric(10, 2) not null,\n  ekp_generated integer not null,\n  notes text not null default '',\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists redemptions (\n  id serial primary key,\n  client_id integer not null references clients(id),\n  article_id integer not null references articles(id),\n  quantity integer not null,\n  ekp_total integer not null,\n  status text not null default 'pendiente',\n  cancel_reason text,\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists tickets (\n  id serial primary key,\n  operation_type text not null,\n  operation_id integer not null,\n  summary text not null,\n  client_name text not null,\n  ekp_amount integer not null,\n  created_at timestamptz not null default now()\n);\n\ncreate index if not exists deliveries_client_idx on deliveries (client_id);\ncreate index if not exists redemptions_client_idx on redemptions (client_id);\ncreate index if not exists tickets_created_idx on tickets (created_at desc);\n\ninsert into hardware_types (name, description, ekp_per_kg, copper_kg_per_kg, silicon_kg_per_kg, gold_g_per_kg)\nselect * from (values\n  ('Placa Madre / Tarjetas Lógicas', 'Motherboards, lógica y controladoras', 500, 0.200, 0.050, 0.250),\n  ('CPU & Procesadores', 'Microprocesadores y sockets', 400, 0.150, 0.280, 0.350),\n  ('Placas de Video / GPU', 'Tarjetas gráficas y aceleradoras', 350, 0.220, 0.120, 0.200),\n  ('Cables & Transformadores', 'Harness, fuentes y cableado de cobre', 50, 0.450, 0.000, 0.000),\n  ('Periféricos & Monitores', 'Teclados, ratones, CRT/LCD y gabinetes', 50, 0.080, 0.020, 0.020)\n) as v(name, description, ekp_per_kg, copper_kg_per_kg, silicon_kg_per_kg, gold_g_per_kg)\nwhere not exists (select 1 from hardware_types);\n\ninsert into clients (name, dni_cuit, client_type, phone, address, email, ekopuntos, status, deactivated_at, created_at)\nselect * from (values\n  ('Escuela Técnica N°1 San José', '30-68901234-8', 'escuela', '3838-421001', 'Av. Las Golondrinas s/n', 'tecnica1@sanjose.edu.ar', 1230, 'activo', null::timestamptz, timestamptz '2026-03-12 09:10:00+00'),\n  ('Colegio Polimodal San José', '30-71234567-2', 'escuela', '3838-421005', 'Calle Belgrano 450', 'polimodal@sanjose.edu.ar', 1800, 'activo', null::timestamptz, timestamptz '2026-03-18 11:00:00+00'),\n  ('Centro Vecinal Zona Norte', '20-28491923-4', 'particular', '3838-429911', 'Barrio Jardín Mza B', 'zonanorte@vecinal.org', 400, 'activo', null::timestamptz, timestamptz '2026-04-02 15:20:00+00'),\n  ('Instituto Formación Técnica', '30-55123987-1', 'escuela', '3838-420099', 'Ruta 40 km 12', 'ift@catamarca.edu.ar', 0, 'inactivo', timestamptz '2026-08-20 12:00:00+00', timestamptz '2026-02-04 10:00:00+00')\n) as v(name, dni_cuit, client_type, phone, address, email, ekopuntos, status, deactivated_at, created_at)\nwhere not exists (select 1 from clients);\n\ninsert into articles (description, category, cost_ekp, stock, active, created_at)\nselect * from (values\n  ('Arduino Uno R3', 'Kits Robótica', 1000, 8, true, timestamptz '2026-01-10 12:00:00+00'),\n  ('Sensor de Humedad y Temperatura DHT11', 'Sensores', 250, 15, true, timestamptz '2026-01-10 12:00:00+00'),\n  ('Sensor Ultrasonido HC-SR04', 'Sensores', 200, 12, true, timestamptz '2026-01-10 12:00:00+00'),\n  ('Servomotor SG90', 'Actuadores', 180, 20, true, timestamptz '2026-01-12 12:00:00+00'),\n  ('Protoboard con cables', 'Kits Robótica', 300, 10, true, timestamptz '2026-01-12 12:00:00+00'),\n  ('Kit de inicio de Robótica Escolar', 'Kits Robótica', 3500, 3, true, timestamptz '2026-01-20 12:00:00+00'),\n  ('Kit Arduino Uno R3 + Sensores Básicos', 'Kits Robótica', 1500, 6, true, timestamptz '2026-02-02 12:00:00+00')\n) as v(description, category, cost_ekp, stock, active, created_at)\nwhere not exists (select 1 from articles);\n\ninsert into deliveries (client_id, hardware_type_id, weight_kg, ekp_generated, notes, created_at)\nselect * from (values\n  (1, 1, 10.50, 5250, 'Lote de gabinetes de laboratorio — 11 placas madre', timestamptz '2026-08-14 10:30:00+00'),\n  (2, 2, 4.20, 1680, 'Procesadores Intel/AMD dados de baja del aula de informática', timestamptz '2026-08-28 09:15:00+00'),\n  (3, 4, 8.00, 400, 'Cables y fuentes recolectados en jornada vecinal', timestamptz '2026-09-05 16:40:00+00'),\n  (1, 3, 2.80, 980, 'Placas de video de PCs de diseño', timestamptz '2026-09-12 11:05:00+00'),\n  (2, 5, 12.40, 620, 'Monitores CRT y periféricos de recambio', timestamptz '2026-09-20 14:22:00+00')\n) as v(client_id, hardware_type_id, weight_kg, ekp_generated, notes, created_at)\nwhere not exists (select 1 from deliveries);\n\ninsert into redemptions (client_id, article_id, quantity, ekp_total, status, cancel_reason, created_at, updated_at)\nselect * from (values\n  (1, 7, 1, 1500, 'entregado', null::text, timestamptz '2026-09-14 10:30:00+00', timestamptz '2026-09-14 11:00:00+00'),\n  (2, 2, 2, 500, 'pendiente', null::text, timestamptz '2026-09-21 09:00:00+00', timestamptz '2026-09-21 09:00:00+00'),\n  (1, 6, 1, 3500, 'entregado', null::text, timestamptz '2026-09-22 12:10:00+00', timestamptz '2026-09-22 12:40:00+00')\n) as v(client_id, article_id, quantity, ekp_total, status, cancel_reason, created_at, updated_at)\nwhere not exists (select 1 from redemptions);\n\ninsert into tickets (operation_type, operation_id, summary, client_name, ekp_amount, created_at)\nselect * from (values\n  ('entrega', 1, 'Recepción 10.5 kg Placa Madre', 'Escuela Técnica N°1 San José', 5250, timestamptz '2026-08-14 10:30:00+00'),\n  ('entrega', 2, 'Recepción 4.2 kg CPU & Procesadores', 'Colegio Polimodal San José', 1680, timestamptz '2026-08-28 09:15:00+00'),\n  ('entrega', 3, 'Recepción 8.0 kg Cables & Transformadores', 'Centro Vecinal Zona Norte', 400, timestamptz '2026-09-05 16:40:00+00'),\n  ('entrega', 4, 'Recepción 2.8 kg Placas de Video / GPU', 'Escuela Técnica N°1 San José', 980, timestamptz '2026-09-12 11:05:00+00'),\n  ('canje', 1, 'Canje de 1× Kit Arduino Uno R3 + Sensores Básicos', 'Escuela Técnica N°1 San José', 1500, timestamptz '2026-09-14 10:30:00+00'),\n  ('entrega', 5, 'Recepción 12.4 kg Periféricos & Monitores', 'Colegio Polimodal San José', 620, timestamptz '2026-09-20 14:22:00+00'),\n  ('canje', 2, 'Canje de 2× Sensor de Humedad y Temperatura DHT11', 'Colegio Polimodal San José', 500, timestamptz '2026-09-21 09:00:00+00'),\n  ('canje', 3, 'Canje de 1× Kit de inicio de Robótica Escolar', 'Escuela Técnica N°1 San José', 3500, timestamptz '2026-09-22 12:10:00+00')\n) as v(operation_type, operation_id, summary, client_name, ekp_amount, created_at)\nwhere not exists (select 1 from tickets);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* **PostgreSQL** cuando `DATABASE_URL` está definida (pgAdmin, Docker, cloud),
* o **PGLite** en memoria en desarrollo sin `.env` (datos no persisten).
*/
var dbSource = databaseUrl ? "postgres" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run, transaction) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	sql.transaction = transaction;
	return sql;
}
var noNestedTransaction = async () => {
	throw new Error("No se permiten transacciones anidadas.");
};
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		}, async (callback) => {
			const client = await pool.connect();
			let destroyClient = false;
			try {
				await client.query("BEGIN");
				const result = await callback(toSql(async (text, params) => {
					return (await client.query(text, params)).rows;
				}, noNestedTransaction));
				await client.query("COMMIT");
				return result;
			} catch (error) {
				try {
					await client.query("ROLLBACK");
				} catch (rollbackError) {
					destroyClient = true;
					console.error("[db] transaction rollback failed:", rollbackError);
				}
				throw error;
			} finally {
				client.release(destroyClient);
			}
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_bitcycle.sql": _0002_bitcycle_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	}, async (callback) => pg.transaction(async (tx) => callback(toSql(async (text, params) => {
		return (await tx.query(text, params)).rows;
	}, noNestedTransaction))));
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "postgres" ? createNeonSql() : createPgliteSql();
}
/**
* Cliente SQL **solo servidor**. PostgreSQL con `DATABASE_URL`, si no PGLite.
* Memoizado — seguro llamar en cada request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **PostgreSQL**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
function iso(value) {
	if (!value) return "";
	if (value instanceof Date) return value.toISOString();
	return String(value);
}
function isoOrNull(value) {
	if (!value) return null;
	return iso(value);
}
function mapClient(row) {
	return {
		id: asNumber(row.id),
		name: String(row.name ?? ""),
		dniCuit: String(row.dni_cuit ?? ""),
		clientType: row.client_type === "particular" ? "particular" : "escuela",
		phone: String(row.phone ?? ""),
		address: String(row.address ?? ""),
		email: String(row.email ?? ""),
		ekopuntos: asNumber(row.ekopuntos),
		status: row.status === "inactivo" ? "inactivo" : "activo",
		deactivatedAt: isoOrNull(row.deactivated_at),
		createdAt: iso(row.created_at)
	};
}
function mapHardware(row) {
	return {
		id: asNumber(row.id),
		name: String(row.name ?? ""),
		description: String(row.description ?? ""),
		ekpPerKg: asNumber(row.ekp_per_kg),
		copperKgPerKg: asNumber(row.copper_kg_per_kg),
		siliconKgPerKg: asNumber(row.silicon_kg_per_kg),
		goldGPerKg: asNumber(row.gold_g_per_kg)
	};
}
function mapArticle(row) {
	return {
		id: asNumber(row.id),
		description: String(row.description ?? ""),
		category: String(row.category ?? ""),
		costEkp: asNumber(row.cost_ekp),
		stock: asNumber(row.stock),
		active: Boolean(row.active),
		createdAt: iso(row.created_at)
	};
}
function mapDelivery(row) {
	return {
		id: asNumber(row.id),
		clientId: asNumber(row.client_id),
		clientName: String(row.client_name ?? ""),
		hardwareTypeId: asNumber(row.hardware_type_id),
		hardwareName: String(row.hardware_name ?? ""),
		weightKg: asNumber(row.weight_kg),
		ekpGenerated: asNumber(row.ekp_generated),
		notes: String(row.notes ?? ""),
		createdAt: iso(row.created_at)
	};
}
function mapRedemption(row) {
	const status = String(row.status ?? "pendiente");
	const safeStatus = status === "entregado" || status === "cancelado" ? status : "pendiente";
	return {
		id: asNumber(row.id),
		clientId: asNumber(row.client_id),
		clientName: String(row.client_name ?? ""),
		articleId: asNumber(row.article_id),
		articleDescription: String(row.article_description ?? ""),
		quantity: asNumber(row.quantity),
		ekpTotal: asNumber(row.ekp_total),
		status: safeStatus,
		cancelReason: row.cancel_reason ? String(row.cancel_reason) : null,
		createdAt: iso(row.created_at),
		updatedAt: iso(row.updated_at)
	};
}
function mapTicket(row) {
	return {
		id: asNumber(row.id),
		operationType: row.operation_type === "canje" ? "canje" : "entrega",
		operationId: asNumber(row.operation_id),
		summary: String(row.summary ?? ""),
		clientName: String(row.client_name ?? ""),
		ekpAmount: asNumber(row.ekp_amount),
		createdAt: iso(row.created_at)
	};
}
var getDashboard_createServerFn_handler = createServerRpc({
	id: "9702758c6fd0cb855b9213cc5e565c91c6cccffe5c6a276226117b92c405025e",
	name: "getDashboard",
	filename: "src/lib/api.ts"
}, (opts) => getDashboard.__executeServer(opts));
var getDashboard = createServerFn({ method: "GET" }).handler(getDashboard_createServerFn_handler, async () => {
	await requireOperator();
	const sql = await getSql();
	const [totals] = await sql`
    select
      coalesce(sum(d.weight_kg), 0) as total_kg,
      coalesce(sum(d.ekp_generated), 0) as total_ekp,
      coalesce(sum(d.weight_kg * h.copper_kg_per_kg), 0) as copper_kg,
      coalesce(sum(d.weight_kg * h.silicon_kg_per_kg), 0) as silicon_kg,
      coalesce(sum(d.weight_kg * h.gold_g_per_kg), 0) as gold_g
    from deliveries d
    join hardware_types h on h.id = d.hardware_type_id
  `;
	const [pending] = await sql`
    select count(*)::int as n from redemptions where status = 'pendiente'
  `;
	const [clients] = await sql`
    select count(*)::int as n from clients where status = 'activo'
  `;
	const [stem] = await sql`
    select coalesce(sum(quantity), 0)::int as n
    from redemptions
    where status = 'entregado'
  `;
	const recentDeliveries = await sql`
    select d.*, c.name as client_name, h.name as hardware_name
    from deliveries d
    join clients c on c.id = d.client_id
    join hardware_types h on h.id = d.hardware_type_id
    order by d.created_at desc
    limit 4
  `;
	const recentTickets = await sql`
    select * from tickets order by created_at desc limit 4
  `;
	return {
		totalKg: asNumber(totals?.total_kg),
		totalEkpIssued: asNumber(totals?.total_ekp),
		pendingRedemptions: asNumber(pending?.n),
		activeClients: asNumber(clients?.n),
		copperKg: asNumber(totals?.copper_kg),
		siliconKg: asNumber(totals?.silicon_kg),
		goldG: asNumber(totals?.gold_g),
		stemUnitsDelivered: asNumber(stem?.n),
		recentDeliveries: recentDeliveries.map(mapDelivery),
		recentTickets: recentTickets.map(mapTicket)
	};
});
var listClients_createServerFn_handler = createServerRpc({
	id: "ff88e4208d74c8d6e8f24c59d7a770c05fc331196e753cb0b233f3829c8ecf31",
	name: "listClients",
	filename: "src/lib/api.ts"
}, (opts) => listClients.__executeServer(opts));
var listClients = createServerFn({ method: "GET" }).handler(listClients_createServerFn_handler, async () => {
	await requireOperator();
	return (await (await getSql())`
    select * from clients order by status asc, name asc
  `).map(mapClient);
});
var listHardwareTypes_createServerFn_handler = createServerRpc({
	id: "081c6385a5e54b8eb837ef37f60dab54e7171514c9f46ba1addd9508ec1f5270",
	name: "listHardwareTypes",
	filename: "src/lib/api.ts"
}, (opts) => listHardwareTypes.__executeServer(opts));
var listHardwareTypes = createServerFn({ method: "GET" }).handler(listHardwareTypes_createServerFn_handler, async () => {
	await requireOperator();
	return (await (await getSql())`
    select * from hardware_types order by ekp_per_kg desc, name asc
  `).map(mapHardware);
});
var listArticles_createServerFn_handler = createServerRpc({
	id: "b4066697b38382bf04a4c60e49c48cdc9c70cac7a7de03603f12f3e4f8b44398",
	name: "listArticles",
	filename: "src/lib/api.ts"
}, (opts) => listArticles.__executeServer(opts));
var listArticles = createServerFn({ method: "GET" }).handler(listArticles_createServerFn_handler, async () => {
	await requireOperator();
	return (await (await getSql())`
    select * from articles order by active desc, category asc, description asc
  `).map(mapArticle);
});
var listRedemptions_createServerFn_handler = createServerRpc({
	id: "881501abbb283835a177bf5e86bd70bff329f31cb64eeee2e01238efc7257941",
	name: "listRedemptions",
	filename: "src/lib/api.ts"
}, (opts) => listRedemptions.__executeServer(opts));
var listRedemptions = createServerFn({ method: "GET" }).handler(listRedemptions_createServerFn_handler, async () => {
	await requireOperator();
	return (await (await getSql())`
    select r.*, c.name as client_name, a.description as article_description
    from redemptions r
    join clients c on c.id = r.client_id
    join articles a on a.id = r.article_id
    order by r.created_at desc
  `).map(mapRedemption);
});
var listTickets_createServerFn_handler = createServerRpc({
	id: "0eecd7b100619c350ac0360f2a295b721eb95db0861b002d18f56d509274b6eb",
	name: "listTickets",
	filename: "src/lib/api.ts"
}, (opts) => listTickets.__executeServer(opts));
var listTickets = createServerFn({ method: "GET" }).handler(listTickets_createServerFn_handler, async () => {
	await requireOperator();
	return (await (await getSql())`
    select * from tickets order by created_at desc
  `).map(mapTicket);
});
var createClient_createServerFn_handler = createServerRpc({
	id: "7eb023852fe655719f65fceab286b3c33f755b7831756abde5380ff497030630",
	name: "createClient",
	filename: "src/lib/api.ts"
}, (opts) => createClient.__executeServer(opts));
var createClient = createServerFn({ method: "POST" }).validator(object({
	name: string().trim().min(3, "Ingresá el nombre o razón social").max(50),
	dniCuit: string().trim().min(7, "Ingresá DNI o CUIT").max(15),
	clientType: _enum(["escuela", "particular"]),
	phone: string().trim().max(20).default(""),
	address: string().trim().max(80).default(""),
	email: string().trim().max(80).default("")
})).handler(createClient_createServerFn_handler, async ({ data }) => {
	await requireOperator();
	const sql = await getSql();
	if ((await sql`
      select id from clients where dni_cuit = ${data.dniCuit} limit 1
    `).length) throw new Error("Ya existe un cliente con ese DNI / CUIT.");
	return mapClient((await sql`
      insert into clients (name, dni_cuit, client_type, phone, address, email)
      values (${data.name}, ${data.dniCuit}, ${data.clientType}, ${data.phone}, ${data.address}, ${data.email})
      returning *
    `)[0]);
});
var setClientStatus_createServerFn_handler = createServerRpc({
	id: "5fcbdf5e28c83a9b3541e1af4bbea35894eaafbffa13e6e3cc1855f55472256c",
	name: "setClientStatus",
	filename: "src/lib/api.ts"
}, (opts) => setClientStatus.__executeServer(opts));
var setClientStatus = createServerFn({ method: "POST" }).validator(object({
	id: number().int(),
	status: _enum(["activo", "inactivo"])
})).handler(setClientStatus_createServerFn_handler, async ({ data }) => {
	await requireOperator();
	const sql = await getSql();
	const deactivatedAt = data.status === "inactivo" ? (/* @__PURE__ */ new Date()).toISOString() : null;
	const rows = await sql`
      update clients
      set status = ${data.status},
          deactivated_at = ${deactivatedAt}
      where id = ${data.id}
      returning *
    `;
	if (!rows[0]) throw new Error("Cliente no encontrado.");
	return mapClient(rows[0]);
});
var createArticle_createServerFn_handler = createServerRpc({
	id: "9dc2e6fabf1fafd82312a2a9a345635d3d183451979f39aec688e9767632e99c",
	name: "createArticle",
	filename: "src/lib/api.ts"
}, (opts) => createArticle.__executeServer(opts));
var createArticle = createServerFn({ method: "POST" }).validator(object({
	description: string().trim().min(3).max(60),
	category: string().trim().min(3).max(50),
	costEkp: number().int().min(1).max(1e5),
	stock: number().int().min(0).max(999999)
})).handler(createArticle_createServerFn_handler, async ({ data }) => {
	await requireOperator();
	return mapArticle((await (await getSql())`
      insert into articles (description, category, cost_ekp, stock)
      values (${data.description}, ${data.category}, ${data.costEkp}, ${data.stock})
      returning *
    `)[0]);
});
var updateArticleCost_createServerFn_handler = createServerRpc({
	id: "a9d89387b01d16a98626e1d37766dd0a630a9cf521c91bc8dd15ecf6658f102d",
	name: "updateArticleCost",
	filename: "src/lib/api.ts"
}, (opts) => updateArticleCost.__executeServer(opts));
var updateArticleCost = createServerFn({ method: "POST" }).validator(object({
	id: number().int(),
	costEkp: number().int().min(1).max(1e5)
})).handler(updateArticleCost_createServerFn_handler, async ({ data }) => {
	await requireOperator();
	const rows = await (await getSql())`
      update articles set cost_ekp = ${data.costEkp} where id = ${data.id} returning *
    `;
	if (!rows[0]) throw new Error("Artículo no encontrado.");
	return mapArticle(rows[0]);
});
var setArticleActive_createServerFn_handler = createServerRpc({
	id: "f659632a3871f92df8440c903ba0c178e3d5f78b32dd33b17ca81b708beec679",
	name: "setArticleActive",
	filename: "src/lib/api.ts"
}, (opts) => setArticleActive.__executeServer(opts));
var setArticleActive = createServerFn({ method: "POST" }).validator(object({
	id: number().int(),
	active: boolean()
})).handler(setArticleActive_createServerFn_handler, async ({ data }) => {
	await requireOperator();
	const rows = await (await getSql())`
      update articles set active = ${data.active} where id = ${data.id} returning *
    `;
	if (!rows[0]) throw new Error("Artículo no encontrado.");
	return mapArticle(rows[0]);
});
var registerDelivery_createServerFn_handler = createServerRpc({
	id: "befea5f824b33f02c203de8787f92eacad90385c46986ffe8ac44c870eb2db4b",
	name: "registerDelivery",
	filename: "src/lib/api.ts"
}, (opts) => registerDelivery.__executeServer(opts));
var registerDelivery = createServerFn({ method: "POST" }).validator(object({
	clientId: number().int(),
	hardwareTypeId: number().int(),
	weightKg: number().positive().max(5e3),
	notes: string().trim().max(200).default("")
})).handler(registerDelivery_createServerFn_handler, async ({ data }) => {
	await requireOperator();
	return (await getSql()).transaction(async (tx) => {
		const client = (await tx`
        select * from clients where id = ${data.clientId} for update
      `)[0];
		if (!client) throw new Error("Seleccioná un cliente o escuela activa.");
		if (client.status !== "activo") throw new Error("El cliente está dado de baja. Reactivalo para acreditar puntos.");
		const hardware = (await tx`
        select * from hardware_types where id = ${data.hardwareTypeId} limit 1
      `)[0];
		if (!hardware) throw new Error("Seleccioná una categoría de hardware.");
		const ekp = Math.round(data.weightKg * asNumber(hardware.ekp_per_kg));
		if (ekp <= 0) throw new Error("El pesaje no genera EkoPuntos. Revisá los kilos ingresados.");
		const inserted = await tx`
        insert into deliveries (client_id, hardware_type_id, weight_kg, ekp_generated, notes)
        values (${data.clientId}, ${data.hardwareTypeId}, ${data.weightKg}, ${ekp}, ${data.notes})
        returning *
      `;
		await tx`
        update clients set ekopuntos = ekopuntos + ${ekp} where id = ${data.clientId}
      `;
		const summary = `Recepción ${data.weightKg.toLocaleString("es-AR")} kg ${String(hardware.name)}`;
		const tickets = await tx`
        insert into tickets (operation_type, operation_id, summary, client_name, ekp_amount)
        values ('entrega', ${asNumber(inserted[0]?.id)}, ${summary}, ${String(client.name)}, ${ekp})
        returning *
      `;
		return {
			delivery: mapDelivery({
				...inserted[0],
				client_name: client.name,
				hardware_name: hardware.name
			}),
			ticket: mapTicket(tickets[0]),
			ekp
		};
	});
});
var registerRedemption_createServerFn_handler = createServerRpc({
	id: "cf70c1d40d5ec961363473c37c4707768ed69cea5a19e964d6c0e8ac33872fe4",
	name: "registerRedemption",
	filename: "src/lib/api.ts"
}, (opts) => registerRedemption.__executeServer(opts));
var registerRedemption = createServerFn({ method: "POST" }).validator(object({
	clientId: number().int(),
	articleId: number().int(),
	quantity: number().int().min(1).max(99)
})).handler(registerRedemption_createServerFn_handler, async ({ data }) => {
	await requireOperator();
	return (await getSql()).transaction(async (tx) => {
		const client = (await tx`
        select * from clients where id = ${data.clientId} for update
      `)[0];
		if (!client) throw new Error("Seleccioná un cliente o escuela.");
		if (client.status !== "activo") throw new Error("El cliente está dado de baja.");
		const article = (await tx`
        select * from articles where id = ${data.articleId} for update
      `)[0];
		if (!article || !article.active) throw new Error("El artículo no está disponible.");
		const stock = asNumber(article.stock);
		if (stock < data.quantity) throw new Error(`Stock insuficiente. Quedan ${stock} unidades.`);
		const total = asNumber(article.cost_ekp) * data.quantity;
		const balance = asNumber(client.ekopuntos);
		if (balance < total) throw new Error(`Saldo insuficiente. Tiene ${balance.toLocaleString("es-AR")} EKP y el canje requiere ${total.toLocaleString("es-AR")} EKP.`);
		const inserted = await tx`
        insert into redemptions (client_id, article_id, quantity, ekp_total, status)
        values (${data.clientId}, ${data.articleId}, ${data.quantity}, ${total}, 'pendiente')
        returning *
      `;
		await tx`
        update clients set ekopuntos = ekopuntos - ${total} where id = ${data.clientId}
      `;
		await tx`
        update articles set stock = stock - ${data.quantity} where id = ${data.articleId}
      `;
		const summary = `Canje de ${data.quantity}× ${String(article.description)}`;
		const tickets = await tx`
        insert into tickets (operation_type, operation_id, summary, client_name, ekp_amount)
        values ('canje', ${asNumber(inserted[0]?.id)}, ${summary}, ${String(client.name)}, ${total})
        returning *
      `;
		return {
			redemption: mapRedemption({
				...inserted[0],
				client_name: client.name,
				article_description: article.description
			}),
			ticket: mapTicket(tickets[0])
		};
	});
});
var updateRedemptionStatus_createServerFn_handler = createServerRpc({
	id: "6ef51b980fd43cd63ee81d3a0412bcd4356fc9b13e7b6bd7c69d8a56577092ac",
	name: "updateRedemptionStatus",
	filename: "src/lib/api.ts"
}, (opts) => updateRedemptionStatus.__executeServer(opts));
var updateRedemptionStatus = createServerFn({ method: "POST" }).validator(object({
	id: number().int(),
	status: _enum(["entregado", "cancelado"]),
	cancelReason: string().trim().max(100).optional()
})).handler(updateRedemptionStatus_createServerFn_handler, async ({ data }) => {
	await requireOperator();
	return (await getSql()).transaction(async (tx) => {
		const current = (await tx`
        select * from redemptions where id = ${data.id} for update
      `)[0];
		if (!current) throw new Error("Canje no encontrado.");
		if (current.status !== "pendiente") throw new Error("Solo se pueden actualizar canjes pendientes.");
		const clients = await tx`
        select name from clients where id = ${asNumber(current.client_id)} limit 1
      `;
		const articles = await tx`
        select description from articles where id = ${asNumber(current.article_id)} limit 1
      `;
		const client = clients[0];
		const article = articles[0];
		if (!client || !article) throw new Error("No se encontraron los datos asociados al canje.");
		let updated;
		if (data.status === "cancelado") {
			const reason = data.cancelReason?.trim();
			if (!reason) throw new Error("Indicá el motivo de cancelación.");
			await tx`
          update clients
          set ekopuntos = ekopuntos + ${asNumber(current.ekp_total)}
          where id = ${asNumber(current.client_id)}
        `;
			await tx`
          update articles
          set stock = stock + ${asNumber(current.quantity)}
          where id = ${asNumber(current.article_id)}
        `;
			updated = await tx`
          update redemptions
          set status = 'cancelado',
              cancel_reason = ${reason},
              updated_at = now()
          where id = ${data.id}
          returning *
        `;
		} else updated = await tx`
          update redemptions
          set status = 'entregado',
              updated_at = now()
          where id = ${data.id}
          returning *
        `;
		return mapRedemption({
			...updated[0],
			client_name: client.name,
			article_description: article.description
		});
	});
});
//#endregion
export { createArticle_createServerFn_handler, createClient_createServerFn_handler, getDashboard_createServerFn_handler, listArticles_createServerFn_handler, listClients_createServerFn_handler, listHardwareTypes_createServerFn_handler, listRedemptions_createServerFn_handler, listTickets_createServerFn_handler, registerDelivery_createServerFn_handler, registerRedemption_createServerFn_handler, setArticleActive_createServerFn_handler, setClientStatus_createServerFn_handler, updateArticleCost_createServerFn_handler, updateRedemptionStatus_createServerFn_handler };
