//#region node_modules/.nitro/vite/services/ssr/assets/errors-Caz7GCy2.js
function errorMessage(error, fallback = "No se pudo completar la operación.") {
	if (error instanceof Error && error.message) {
		const msg = error.message;
		if (msg.includes("Failed to fetch") || msg.includes("NetworkError")) return "Sin conexión con el servidor. Reintentá cuando vuelva la red.";
		return msg;
	}
	if (typeof error === "string" && error) return error;
	return fallback;
}
//#endregion
export { errorMessage as t };
