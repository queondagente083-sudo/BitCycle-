import { t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, n as boolean } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-F4OpR4aR.js
var readOperatorServer = async () => {
	const { readOperator } = await import("./auth.server-BvXA_zGT.mjs");
	return readOperator();
};
var getCurrentOperator_createServerFn_handler = createServerRpc({
	id: "47daa29c7a03b32d905db7c9f51259bd441d9fdddd2cf51f5230f732610b67cf",
	name: "getCurrentOperator",
	filename: "src/lib/auth.ts"
}, (opts) => getCurrentOperator.__executeServer(opts));
var getCurrentOperator = createServerFn({ method: "GET" }).handler(getCurrentOperator_createServerFn_handler, () => readOperatorServer());
var signIn_createServerFn_handler = createServerRpc({
	id: "600f8bfbba8479142f4e053530bf73429a7c4605f126101c81fcfe0af5d16585",
	name: "signIn",
	filename: "src/lib/auth.ts"
}, (opts) => signIn.__executeServer(opts));
var signIn = createServerFn({ method: "POST" }).validator(object({
	username: string().trim().min(1).max(80),
	password: string().min(1).max(200),
	remembered: boolean()
})).handler(signIn_createServerFn_handler, async ({ data }) => {
	const { signInOperator } = await import("./auth.server-BvXA_zGT.mjs");
	return signInOperator(data);
});
var signOut_createServerFn_handler = createServerRpc({
	id: "2ebab109cf2a30c0cf504179c4ac08c940ffdcf80725116fefa68023748a7a67",
	name: "signOut",
	filename: "src/lib/auth.ts"
}, (opts) => signOut.__executeServer(opts));
var signOut = createServerFn({ method: "POST" }).handler(signOut_createServerFn_handler, async () => {
	const { signOutOperator } = await import("./auth.server-BvXA_zGT.mjs");
	await signOutOperator();
});
//#endregion
export { getCurrentOperator_createServerFn_handler, signIn_createServerFn_handler, signOut_createServerFn_handler };
