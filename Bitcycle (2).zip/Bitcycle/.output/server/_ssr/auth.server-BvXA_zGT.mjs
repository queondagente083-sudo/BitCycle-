import { a as getSession$1, i as clearSession$1, o as updateSession$1 } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.server-BvXA_zGT.js
var SESSION_COOKIE = "bitcycle-session";
var SESSION_MAX_AGE_SECONDS = 28800;
function sessionConfig(remembered = false) {
	const password = process.env.BITCYCLE_SESSION_SECRET;
	if (!password || password.length < 32) throw new Error("Configurá BITCYCLE_SESSION_SECRET con al menos 32 caracteres.");
	return {
		name: SESSION_COOKIE,
		password,
		maxAge: SESSION_MAX_AGE_SECONDS,
		cookie: {
			httpOnly: true,
			sameSite: "lax",
			secure: true,
			path: "/",
			...remembered ? {} : {
				maxAge: void 0,
				expires: void 0
			}
		}
	};
}
function configuredCredential(prefix) {
	const username = process.env[`BITCYCLE_${prefix}_USERNAME`]?.trim();
	const password = process.env[`BITCYCLE_${prefix}_PASSWORD`];
	if (!username || !password) throw new Error(`Configurá BITCYCLE_${prefix}_USERNAME y BITCYCLE_${prefix}_PASSWORD.`);
	if (password.length < 12) throw new Error(`BITCYCLE_${prefix}_PASSWORD debe tener al menos 12 caracteres.`);
	return {
		username,
		password
	};
}
function constantTimeEqual(left, right) {
	const leftBytes = new TextEncoder().encode(left);
	const rightBytes = new TextEncoder().encode(right);
	let difference = leftBytes.length ^ rightBytes.length;
	const length = Math.max(leftBytes.length, rightBytes.length);
	for (let index = 0; index < length; index += 1) difference |= (leftBytes[index] ?? 0) ^ (rightBytes[index] ?? 0);
	return difference === 0;
}
function validOperator(value) {
	if (!value || typeof value !== "object") return false;
	const operator = value;
	return typeof operator.username === "string" && typeof operator.displayName === "string" && (operator.role === "operador" || operator.role === "admin");
}
async function readOperator() {
	const session = await getSession$1(sessionConfig());
	return validOperator(session.data.operator) ? session.data.operator : null;
}
async function requireOperator() {
	const operator = await readOperator();
	if (!operator) throw new Error("La sesión expiró. Iniciá sesión nuevamente.");
	return operator;
}
async function signInOperator(data) {
	const operatorCredential = configuredCredential("OPERATOR");
	const adminCredential = configuredCredential("ADMIN");
	if (operatorCredential.username.toLowerCase() === adminCredential.username.toLowerCase()) throw new Error("Las credenciales de operador y administración deben tener usuarios distintos.");
	const match = [{
		credential: operatorCredential,
		role: "operador",
		displayName: "Operador San José"
	}, {
		credential: adminCredential,
		role: "admin",
		displayName: "Dirección Operativa"
	}].find(({ credential }) => credential.username.toLowerCase() === data.username.toLowerCase() && constantTimeEqual(credential.password, data.password));
	if (!match) return null;
	const operator = {
		username: match.credential.username,
		displayName: match.displayName,
		role: match.role
	};
	await updateSession$1(sessionConfig(data.remembered), { operator });
	return operator;
}
async function signOutOperator() {
	await clearSession$1(sessionConfig());
}
//#endregion
export { readOperator, requireOperator, signInOperator, signOutOperator };
