import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { u as Recycle } from "../_libs/lucide-react.mjs";
import { i as cn } from "./button-jQD-qwDa.mjs";
import { a as formatEkp, i as formatDateTime, l as ticketCode } from "./format-DXO4Tf2J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ticket-card-Dwf5aUy-.js
var import_jsx_runtime = require_jsx_runtime();
function TicketFace({ ticket, className }) {
	const code = ticketCode(ticket.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("overflow-hidden rounded-lg border border-line bg-elevated text-ink", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between bg-forest px-4 py-3 text-elevated",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recycle, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-base font-semibold",
						children: "BitCycle"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs tabular-nums tracking-wide",
					children: code
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-wider text-muted",
							children: "Cliente"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-medium",
							children: ticket.clientName
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-wider text-muted",
							children: "Operación"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: ticket.operationType === "entrega" ? "Acreditación RAEE" : "Canje premio STEM" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-wider text-muted",
							children: "Detalle"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: ticket.summary })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-wider text-muted",
								children: "Monto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display text-2xl font-semibold tabular-nums text-leaf-dark",
								children: formatEkp(ticket.ekpAmount)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: formatDateTime(ticket.createdAt)
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-t border-line px-4 py-2 text-[0.7rem] text-muted",
				children: "Planta San José · Santa María, Catamarca · Comprobante interno no fiscal"
			})
		]
	});
}
//#endregion
export { TicketFace as t };
