import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, n as boolean } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-JuGpVpOr.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var requireOperator = async () => {
	const { requireOperator: requireServerOperator } = await import("./auth.server-BvXA_zGT.mjs");
	return requireServerOperator();
};
var getCurrentOperator = createServerFn({ method: "GET" }).handler(createSsrRpc("47daa29c7a03b32d905db7c9f51259bd441d9fdddd2cf51f5230f732610b67cf"));
var signIn = createServerFn({ method: "POST" }).validator(object({
	username: string().trim().min(1).max(80),
	password: string().min(1).max(200),
	remembered: boolean()
})).handler(createSsrRpc("600f8bfbba8479142f4e053530bf73429a7c4605f126101c81fcfe0af5d16585"));
var signOut = createServerFn({ method: "POST" }).handler(createSsrRpc("2ebab109cf2a30c0cf504179c4ac08c940ffdcf80725116fefa68023748a7a67"));
//#endregion
export { signOut as a, signIn as i, getCurrentOperator as n, requireOperator as r, createSsrRpc as t };
