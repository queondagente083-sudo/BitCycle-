import { o as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { C as Check, f as Plus, t as X } from "./_libs/lucide-react.mjs";
import { n as Button } from "./_ssr/button-jQD-qwDa.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { r as Surface, t as PageHeader } from "./_ssr/plant-shell-jOF6YvpC.mjs";
import { a as formatEkp, c as redemptionCode, i as formatDateTime } from "./_ssr/format-DXO4Tf2J.mjs";
import { t as Badge } from "./_ssr/badge-us6zkbE_.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogFooter, t as Dialog } from "./_ssr/dialog-WKnERYLq.mjs";
import { t as Input } from "./_ssr/input-Ch0xPnGe.mjs";
import { t as Label } from "./_ssr/label-BtZbXsk9.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-DdzIPFgf.mjs";
import { t as Textarea } from "./_ssr/textarea-BAGB3s-O.mjs";
import { a as listClients, i as listArticles, m as updateRedemptionStatus, s as listRedemptions, u as registerRedemption } from "./_ssr/api-B6qAg5ds.mjs";
import { t as errorMessage } from "./_ssr/errors-Caz7GCy2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_plant.canjes-9iL4WhVN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CanjesPage() {
	const queryClient = useQueryClient();
	const redemptions = useQuery({
		queryKey: ["redemptions"],
		queryFn: () => listRedemptions()
	});
	const clients = useQuery({
		queryKey: ["clients"],
		queryFn: () => listClients()
	});
	const articles = useQuery({
		queryKey: ["articles"],
		queryFn: () => listArticles()
	});
	const [open, setOpen] = (0, import_react.useState)(false);
	const [clientId, setClientId] = (0, import_react.useState)("");
	const [articleId, setArticleId] = (0, import_react.useState)("");
	const [quantity, setQuantity] = (0, import_react.useState)("1");
	const [cancelTarget, setCancelTarget] = (0, import_react.useState)(null);
	const [reason, setReason] = (0, import_react.useState)("");
	const selectedClient = clients.data?.find((c) => String(c.id) === clientId);
	const selectedArticle = articles.data?.find((a) => String(a.id) === articleId);
	const qty = Math.max(1, parseInt(quantity, 10) || 1);
	const total = (selectedArticle?.costEkp ?? 0) * qty;
	const canAfford = (selectedClient?.ekopuntos ?? 0) >= total;
	const inStock = (selectedArticle?.stock ?? 0) >= qty;
	const availableArticles = (articles.data ?? []).filter((a) => a.active && a.stock > 0);
	const activeClients = (clients.data ?? []).filter((c) => c.status === "activo");
	function invalidate() {
		queryClient.invalidateQueries({ queryKey: ["redemptions"] });
		queryClient.invalidateQueries({ queryKey: ["clients"] });
		queryClient.invalidateQueries({ queryKey: ["articles"] });
		queryClient.invalidateQueries({ queryKey: ["dashboard"] });
		queryClient.invalidateQueries({ queryKey: ["tickets"] });
	}
	const createMutation = useMutation({
		mutationFn: () => registerRedemption({ data: {
			clientId: Number(clientId),
			articleId: Number(articleId),
			quantity: qty
		} }),
		onSuccess: () => {
			toast.success("Canje registrado. Queda pendiente de entrega.");
			setOpen(false);
			setArticleId("");
			setQuantity("1");
			invalidate();
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const statusMutation = useMutation({
		mutationFn: (input) => updateRedemptionStatus({ data: input }),
		onSuccess: (_, vars) => {
			toast.success(vars.status === "entregado" ? "Marcado como entregado." : "Canje cancelado. Se reintegraron puntos y stock.");
			setCancelTarget(null);
			setReason("");
			invalidate();
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const rows = redemptions.data ?? [];
	const pending = (0, import_react.useMemo)(() => rows.filter((r) => r.status === "pendiente").length, [rows]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Canjes STEM",
			description: "Canjeá EkoPuntos por kits, sensores y actuadores. El stock se descuenta al confirmar.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Nuevo canje"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Pendientes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-semibold tabular-nums",
						children: pending
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Operaciones"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-semibold tabular-nums",
						children: rows.length
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-muted",
						children: "Entregados"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-semibold tabular-nums",
						children: rows.filter((r) => r.status === "entregado").length
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, {
			className: "overflow-hidden p-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[44rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-mist text-xs uppercase tracking-wider text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Código"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Fecha"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Cliente"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Artículo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Cant."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "EKP"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Estado"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Acciones"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 8,
						className: "px-4 py-10 text-center text-muted",
						children: "Todavía no hay canjes. Registrá el primero desde el botón superior."
					}) }), rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: redemptionCode(row.id)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted",
								children: formatDateTime(row.createdAt)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: row.clientName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: row.articleDescription
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: row.quantity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: formatEkp(row.ekpTotal)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: row.status })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: row.status === "pendiente" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "secondary",
										onClick: () => statusMutation.mutate({
											id: row.id,
											status: "entregado"
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), "Entregar"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: () => {
											setCancelTarget(row);
											setReason("");
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" }), "Anular"]
									})]
								}) : row.cancelReason ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: row.cancelReason
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: "—"
								})
							})
						]
					}, row.id))] })]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Registrar canje STEM" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Cliente / escuela" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: clientId || void 0,
								onValueChange: setClientId,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Seleccionar escuela o particular" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: activeClients.map((client) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: String(client.id),
									children: [
										client.name,
										" · ",
										formatEkp(client.ekopuntos)
									]
								}, client.id)) })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Premio / artículo STEM" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: articleId || void 0,
								onValueChange: setArticleId,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Seleccionar premio del catálogo" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: availableArticles.map((article) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: String(article.id),
									children: [
										article.description,
										" · ",
										formatEkp(article.costEkp),
										" · stock ",
										article.stock
									]
								}, article.id)) })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "qty",
								children: "Cantidad"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "qty",
								type: "number",
								min: 1,
								value: quantity,
								onChange: (e) => setQuantity(e.target.value)
							})]
						}),
						selectedArticle && selectedClient && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md bg-mist px-3 py-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Costo: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: formatEkp(total) })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: canAfford ? "text-muted" : "text-danger",
									children: [
										"Saldo: ",
										formatEkp(selectedClient.ekopuntos),
										canAfford ? ` · queda ${formatEkp(selectedClient.ekopuntos - total)}` : " · insuficiente"
									]
								}),
								!inStock && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-danger",
									children: "Stock insuficiente."
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setOpen(false),
					children: "Cancelar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !clientId || !articleId || !canAfford || !inStock || createMutation.isPending,
					onClick: () => createMutation.mutate(),
					children: "Confirmar canje"
				})] })
			] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!cancelTarget,
			onOpenChange: (openState) => !openState && setCancelTarget(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Cancelar canje" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Se reintegrarán los EkoPuntos y el stock. Indicá el motivo para la auditoría."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					placeholder: "Motivo de cancelación",
					value: reason,
					onChange: (e) => setReason(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setCancelTarget(null),
					children: "Volver"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "destructive",
					disabled: !reason.trim() || statusMutation.isPending,
					onClick: () => {
						if (!cancelTarget) return;
						statusMutation.mutate({
							id: cancelTarget.id,
							status: "cancelado",
							cancelReason: reason.trim()
						});
					},
					children: "Confirmar anulación"
				})] })
			] })
		})
	] });
}
function StatusBadge({ status }) {
	if (status === "entregado") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "leaf",
		children: "Entregado"
	});
	if (status === "cancelado") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "danger",
		children: "Cancelado"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: "warn",
		children: "Pendiente"
	});
}
//#endregion
export { CanjesPage as component };
