import { o as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as cn, n as Button } from "./_ssr/button-jQD-qwDa.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { r as Surface, t as PageHeader } from "./_ssr/plant-shell-jOF6YvpC.mjs";
import { a as formatEkp, s as formatKg } from "./_ssr/format-DXO4Tf2J.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./_ssr/dialog-WKnERYLq.mjs";
import { t as Input } from "./_ssr/input-Ch0xPnGe.mjs";
import { t as Label } from "./_ssr/label-BtZbXsk9.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-DdzIPFgf.mjs";
import { t as Textarea } from "./_ssr/textarea-BAGB3s-O.mjs";
import { a as listClients, l as registerDelivery, o as listHardwareTypes } from "./_ssr/api-B6qAg5ds.mjs";
import { t as errorMessage } from "./_ssr/errors-Caz7GCy2.mjs";
import { t as TicketFace } from "./_ssr/ticket-card-Dwf5aUy-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_plant.recepcion-BbConM9F.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RecepcionPage() {
	const queryClient = useQueryClient();
	const clients = useQuery({
		queryKey: ["clients"],
		queryFn: () => listClients()
	});
	const hardware = useQuery({
		queryKey: ["hardware"],
		queryFn: () => listHardwareTypes()
	});
	const [clientId, setClientId] = (0, import_react.useState)("");
	const [hardwareId, setHardwareId] = (0, import_react.useState)("");
	const [weight, setWeight] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [ticket, setTicket] = (0, import_react.useState)(null);
	const selectedHardware = hardware.data?.find((item) => String(item.id) === hardwareId);
	const selectedClient = clients.data?.find((item) => String(item.id) === clientId);
	const weightNum = parseFloat(weight.replace(",", "."));
	const ekp = (0, import_react.useMemo)(() => {
		if (!selectedHardware || !Number.isFinite(weightNum) || weightNum <= 0) return 0;
		return Math.round(weightNum * selectedHardware.ekpPerKg);
	}, [selectedHardware, weightNum]);
	const invalidate = () => {
		queryClient.invalidateQueries({ queryKey: ["dashboard"] });
		queryClient.invalidateQueries({ queryKey: ["clients"] });
		queryClient.invalidateQueries({ queryKey: ["tickets"] });
	};
	const mutation = useMutation({
		mutationFn: () => registerDelivery({ data: {
			clientId: Number(clientId),
			hardwareTypeId: Number(hardwareId),
			weightKg: weightNum,
			notes
		} }),
		onSuccess: (result) => {
			toast.success(`Se acreditaron ${formatEkp(result.ekp)}`);
			setTicket(result.ticket);
			setWeight("");
			setNotes("");
			queryClient.setQueryData(["clients"], (current) => (current ?? []).map((client) => client.id === Number(clientId) ? {
				...client,
				ekopuntos: client.ekopuntos + result.ekp
			} : client));
			invalidate();
		},
		onError: (err) => toast.error(errorMessage(err))
	});
	const activeClients = (clients.data ?? []).filter((c) => c.status === "activo");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Recepción de RAEE",
			description: "Pesaje asistido y cálculo automático de EkoPuntos. Pensado para pocos clics en mostrador."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_18rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "1. Cliente o escuela beneficiaria" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: clientId || void 0,
								onValueChange: setClientId,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Seleccionar escuela o particular" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: activeClients.map((client) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: String(client.id),
									children: [
										client.name,
										" · ",
										formatEkp(client.ekopuntos)
									]
								}, client.id)) })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "2. Categoría de hardware" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: hardwareId || void 0,
									onValueChange: setHardwareId,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Seleccionar tipo de RAEE" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (hardware.data ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: String(item.id),
										children: item.name
									}, item.id)) })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "peso",
									children: "3. Peso de balanza (kg)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
										"aria-hidden": "true",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "1.8",
										strokeLinecap: "round",
										strokeLinejoin: "round",
										className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 3v18M5 7h14M7 7l-4 7h8L7 7Zm10 0-4 7h8l-4-7ZM8 21h8" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "peso",
										inputMode: "decimal",
										placeholder: "0.0",
										className: "pl-10",
										value: weight,
										onChange: (e) => setWeight(e.target.value)
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-lg bg-mist px-4 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wider text-muted",
								children: "Puntaje calculado"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: selectedHardware ? `${selectedHardware.ekpPerKg} EKP / kg` : "Elegí categoría y peso"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-4xl font-semibold tabular-nums text-leaf-dark",
								children: [ekp, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-1 text-base font-medium",
									children: "EKP"
								})]
							})]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "notas",
								children: "Observaciones (opcional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "notas",
								placeholder: "Ej. Lote de 11 gabinetes del laboratorio",
								value: notes,
								onChange: (e) => setNotes(e.target.value)
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-5 w-full",
					size: "lg",
					disabled: !clientId || !hardwareId || ekp <= 0 || mutation.isPending,
					onClick: () => mutation.mutate(),
					children: mutation.isPending ? "Acreditando…" : "Confirmar entrega y acreditar EkoPuntos"
				}),
				selectedClient && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-center text-sm text-muted",
					children: [
						"Saldo actual de ",
						selectedClient.name,
						": ",
						formatEkp(selectedClient.ekopuntos)
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "h-fit",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-3 font-display text-lg font-semibold",
						children: "Tabla de valorización"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: (hardware.data ?? []).map((item) => {
							const active = String(item.id) === hardwareId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setHardwareId(String(item.id)),
								className: cn("flex w-full items-start justify-between gap-2 rounded-md border px-3 py-2.5 text-left text-sm transition-colors", active ? "border-leaf bg-mist" : "border-line hover:bg-paper"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium",
									children: item.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: item.description
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "shrink-0 font-medium tabular-nums text-leaf-dark",
									children: [item.ekpPerKg, " EKP/kg"]
								})]
							}) }, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-muted",
						children: "Los EkoPuntos se generan en el servidor. El operador no calcula a mano."
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!ticket,
			onOpenChange: (open) => !open && setTicket(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Tique digital emitido" }) }),
				ticket && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketFace, { ticket }),
				ticket && selectedClient && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Nuevo saldo estimado: ",
						formatEkp(selectedClient.ekopuntos + ticket.ekpAmount),
						Number.isFinite(weightNum) ? ` · ${formatKg(weightNum)} acopiados` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setTicket(null),
					children: "Cerrar y continuar"
				})
			] })
		})
	] });
}
//#endregion
export { RecepcionPage as component };
