globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as serve, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, s as NodeResponse, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/badge-D6k7VUkq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"295-XP1cuX/elSnIYbxhjLa2uSexFt0\"",
		"mtime": "2026-10-25T02:31:31.276Z",
		"size": 661,
		"path": "../public/assets/badge-D6k7VUkq.js"
	},
	"/assets/dist-VjISa2gp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ee-m+gu55qahjaUGO2xxASnoC79xjk\"",
		"mtime": "2026-10-25T02:31:31.276Z",
		"size": 750,
		"path": "../public/assets/dist-VjISa2gp.js"
	},
	"/assets/auth-D7QxINs_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d3cb-zZUJH4qcfHGFxW+AEKQDJvRMaSA\"",
		"mtime": "2026-10-25T02:31:31.275Z",
		"size": 54219,
		"path": "../public/assets/auth-D7QxINs_.js"
	},
	"/assets/dialog-CKNSqNIz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"752-tlTz3Eex6NGI6xgbc710kApKWew\"",
		"mtime": "2026-10-25T02:31:31.276Z",
		"size": 1874,
		"path": "../public/assets/dialog-CKNSqNIz.js"
	},
	"/assets/errors-B3cbsWOO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11d-28TwPTLBjJ5bCXGvSKHCoCyDQOg\"",
		"mtime": "2026-10-25T02:31:31.278Z",
		"size": 285,
		"path": "../public/assets/errors-B3cbsWOO.js"
	},
	"/assets/dist-XpHPBqTo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bded-8KpI3+j8Sah528CAeBrE82dFayk\"",
		"mtime": "2026-10-25T02:31:31.278Z",
		"size": 48621,
		"path": "../public/assets/dist-XpHPBqTo.js"
	},
	"/assets/format-B7N2_czM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"750c-zXp1Q/17mIk3SPB4WziNd9h0SAA\"",
		"mtime": "2026-10-25T02:31:31.278Z",
		"size": 29964,
		"path": "../public/assets/format-B7N2_czM.js"
	},
	"/assets/input-DSxCRVcD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22c-wmj0sVPQqSdxZMO+mf0W24EOblA\"",
		"mtime": "2026-10-25T02:31:31.278Z",
		"size": 556,
		"path": "../public/assets/input-DSxCRVcD.js"
	},
	"/assets/label-9E6XFh3F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"264-xokJRJfkj3tX7Ya0ogJTqeEDVIo\"",
		"mtime": "2026-10-25T02:31:31.278Z",
		"size": 612,
		"path": "../public/assets/label-9E6XFh3F.js"
	},
	"/assets/plant-shell-AkSXxetW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9481-xkH5UDNXPdLP7VvNVY1aaUxEIek\"",
		"mtime": "2026-10-25T02:31:31.279Z",
		"size": 38017,
		"path": "../public/assets/plant-shell-AkSXxetW.js"
	},
	"/assets/rolldown-runtime-CbXtAM7H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24d-+aXgvbJ1Wwcp2A8AXKIBByksYC8\"",
		"mtime": "2026-10-25T02:31:31.283Z",
		"size": 589,
		"path": "../public/assets/rolldown-runtime-CbXtAM7H.js"
	},
	"/assets/query-Qz8UOvqH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f2cc-60pNVCj4mfxZbe6rPsbENGWldgA\"",
		"mtime": "2026-10-25T02:31:31.282Z",
		"size": 62156,
		"path": "../public/assets/query-Qz8UOvqH.js"
	},
	"/assets/index-CV1UwRqA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"47d2b-Ow5Hq4MZuc0/lgoZ/MWEE+mVWN4\"",
		"mtime": "2026-10-25T02:31:31.272Z",
		"size": 294187,
		"path": "../public/assets/index-CV1UwRqA.js"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"2c9-ZJeqe0LdesX7AzhP+nfYGPX6Mlw\"",
		"mtime": "2026-10-21T01:20:43.220Z",
		"size": 713,
		"path": "../public/favicon.svg"
	},
	"/assets/routes-BXzc6CRn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"243b-iPsynVT6dQYN08TteXnDhSqCz7w\"",
		"mtime": "2026-10-25T02:31:31.283Z",
		"size": 9275,
		"path": "../public/assets/routes-BXzc6CRn.js"
	},
	"/og.jpg": {
		"type": "image/jpeg",
		"etag": "\"17c5c-7jNd/1OSstbVF6o3UZpWzd+6KTU\"",
		"mtime": "2026-10-21T01:20:43.234Z",
		"size": 97372,
		"path": "../public/og.jpg"
	},
	"/assets/select-cvc88EDR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c821-S8E9pxjUougg4MPA4P92LviXshY\"",
		"mtime": "2026-10-25T02:31:31.283Z",
		"size": 51233,
		"path": "../public/assets/select-cvc88EDR.js"
	},
	"/assets/search-LCQ9IYRk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a3-axY/m+NxTKX17jy5BfEzlFdTzR0\"",
		"mtime": "2026-10-25T02:31:31.283Z",
		"size": 163,
		"path": "../public/assets/search-LCQ9IYRk.js"
	},
	"/assets/textarea-DMD10Bek.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21b-fCiRHI7Q1XLAspEK2md6vcrjgeM\"",
		"mtime": "2026-10-25T02:31:31.285Z",
		"size": 539,
		"path": "../public/assets/textarea-DMD10Bek.js"
	},
	"/assets/ticket-card-CPdjBQRb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7a4-515U2x8DtyGouY+yzsP546FbBqw\"",
		"mtime": "2026-10-25T02:31:31.285Z",
		"size": 1956,
		"path": "../public/assets/ticket-card-CPdjBQRb.js"
	},
	"/assets/_plant--iC7tq7W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"da-emp8Ffj+BZTWF1Fhdtis2njC7f8\"",
		"mtime": "2026-10-25T02:31:31.273Z",
		"size": 218,
		"path": "../public/assets/_plant--iC7tq7W.js"
	},
	"/assets/_plant.canjes-BI_aGSbu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f62-PAS1tTg+0gD7XWy7bP6nByjcQNg\"",
		"mtime": "2026-10-25T02:31:31.273Z",
		"size": 8034,
		"path": "../public/assets/_plant.canjes-BI_aGSbu.js"
	},
	"/assets/_plant.clientes-Co2AJjDC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"197b-Hx0iOqldLmYdBdpagJkv95qGSEs\"",
		"mtime": "2026-10-25T02:31:31.274Z",
		"size": 6523,
		"path": "../public/assets/_plant.clientes-Co2AJjDC.js"
	},
	"/assets/_plant.catalogo-ByiWeQFV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18ed-fxKb+dRdww7/N5gFskmZZW0Yn/M\"",
		"mtime": "2026-10-25T02:31:31.273Z",
		"size": 6381,
		"path": "../public/assets/_plant.catalogo-ByiWeQFV.js"
	},
	"/assets/styles-CFOP1v99.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"79b3-FdjhcHCN97fwbywLiJ2uCzU2RD4\"",
		"mtime": "2026-10-25T02:31:31.291Z",
		"size": 31155,
		"path": "../public/assets/styles-CFOP1v99.css"
	},
	"/assets/_plant.panel-DlF8UYMH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c09-ckly91+skdTrwd1vM4a6g+VBBtM\"",
		"mtime": "2026-10-25T02:31:31.274Z",
		"size": 7177,
		"path": "../public/assets/_plant.panel-DlF8UYMH.js"
	},
	"/assets/_plant.tiques-Cgj3aX2P.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bc9-Pg9+p47BJWgFMJq0J4ZetwLUmnY\"",
		"mtime": "2026-10-25T02:31:31.275Z",
		"size": 3017,
		"path": "../public/assets/_plant.tiques-Cgj3aX2P.js"
	},
	"/assets/_plant.recepcion-B_yI3vvd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1711-Kve3M71DZMeTDrDofsNx/b+bgh0\"",
		"mtime": "2026-10-25T02:31:31.275Z",
		"size": 5905,
		"path": "../public/assets/_plant.recepcion-B_yI3vvd.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_yoIil7 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_yoIil7
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
