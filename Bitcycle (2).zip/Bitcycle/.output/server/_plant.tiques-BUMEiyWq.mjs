import { o as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { c as Search, d as Printer } from "./_libs/lucide-react.mjs";
import { n as Button } from "./_ssr/button-jQD-qwDa.mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { r as Surface, t as PageHeader } from "./_ssr/plant-shell-jOF6YvpC.mjs";
import { a as formatEkp, i as formatDateTime, l as ticketCode } from "./_ssr/format-DXO4Tf2J.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./_ssr/dialog-WKnERYLq.mjs";
import { t as Input } from "./_ssr/input-Ch0xPnGe.mjs";
import { c as listTickets } from "./_ssr/api-B6qAg5ds.mjs";
import { t as TicketFace } from "./_ssr/ticket-card-Dwf5aUy-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_plant.tiques-BUMEiyWq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TiquesPage() {
	const tickets = useQuery({
		queryKey: ["tickets"],
		queryFn: () => listTickets()
	});
	const [query, setQuery] = (0, import_react.useState)("");
	const [selected, setSelected] = (0, import_react.useState)(null);
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return (tickets.data ?? []).filter((ticket) => {
			if (!q) return true;
			return [
				ticket.clientName,
				ticket.summary,
				ticketCode(ticket.id),
				ticket.operationType
			].join(" ").toLowerCase().includes(q);
		});
	}, [tickets.data, query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Tiques digitales",
			description: "Comprobantes de acreditación RAEE y canjes STEM. Se emiten solos al confirmar cada operación."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, {
			className: "mb-4 p-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "pl-10",
					placeholder: "Buscar por cliente, código o detalle",
					value: query,
					onChange: (e) => setQuery(e.target.value)
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: [filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Surface, {
				className: "md:col-span-2 py-12 text-center text-sm text-muted",
				children: "No hay tiques para mostrar."
			}), filtered.map((ticket) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Surface, {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tabular-nums text-muted",
								children: ticketCode(ticket.id)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: ticket.clientName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: ticket.operationType === "entrega" ? "Acreditación RAEE" : "Canje premio STEM"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: formatDateTime(ticket.createdAt)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: ticket.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl font-semibold tabular-nums text-leaf-dark",
							children: formatEkp(ticket.ekpAmount)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "forest",
							size: "sm",
							onClick: () => setSelected(ticket),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3.5" }), "Ver e imprimir"]
						})]
					})
				]
			}, ticket.id))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!selected,
			onOpenChange: (open) => !open && setSelected(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-w-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Comprobante" }) }),
					selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "print-ticket",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketFace, { ticket: selected })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => {
							window.print();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Imprimir tique"]
					})
				]
			})
		})
	] });
}
//#endregion
export { TiquesPage as component };
