//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CkpZq65W.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Bitcycle/src/routes/__root.tsx",
		children: ["/", "/_plant"],
		preloads: [
			"/assets/index-CV1UwRqA.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/query-Qz8UOvqH.js",
			"/assets/dist-XpHPBqTo.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CV1UwRqA.js"
		} }]
	},
	"/": {
		filePath: "D:/Bitcycle/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BXzc6CRn.js",
			"/assets/auth-D7QxINs_.js",
			"/assets/dist-VjISa2gp.js",
			"/assets/input-DSxCRVcD.js",
			"/assets/label-9E6XFh3F.js"
		]
	},
	"/_plant": {
		filePath: "D:/Bitcycle/src/routes/_plant.tsx",
		children: [
			"/_plant/canjes",
			"/_plant/catalogo",
			"/_plant/clientes",
			"/_plant/panel",
			"/_plant/recepcion",
			"/_plant/tiques"
		],
		preloads: ["/assets/_plant--iC7tq7W.js", "/assets/plant-shell-AkSXxetW.js"]
	},
	"/_plant/canjes": {
		filePath: "D:/Bitcycle/src/routes/_plant.canjes.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.canjes-BI_aGSbu.js",
			"/assets/auth-D7QxINs_.js",
			"/assets/dist-VjISa2gp.js",
			"/assets/select-cvc88EDR.js",
			"/assets/badge-D6k7VUkq.js",
			"/assets/dialog-CKNSqNIz.js",
			"/assets/input-DSxCRVcD.js",
			"/assets/label-9E6XFh3F.js",
			"/assets/textarea-DMD10Bek.js",
			"/assets/format-B7N2_czM.js",
			"/assets/errors-B3cbsWOO.js"
		]
	},
	"/_plant/catalogo": {
		filePath: "D:/Bitcycle/src/routes/_plant.catalogo.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.catalogo-ByiWeQFV.js",
			"/assets/auth-D7QxINs_.js",
			"/assets/badge-D6k7VUkq.js",
			"/assets/dialog-CKNSqNIz.js",
			"/assets/input-DSxCRVcD.js",
			"/assets/label-9E6XFh3F.js",
			"/assets/format-B7N2_czM.js",
			"/assets/errors-B3cbsWOO.js"
		]
	},
	"/_plant/clientes": {
		filePath: "D:/Bitcycle/src/routes/_plant.clientes.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.clientes-Co2AJjDC.js",
			"/assets/auth-D7QxINs_.js",
			"/assets/select-cvc88EDR.js",
			"/assets/badge-D6k7VUkq.js",
			"/assets/search-LCQ9IYRk.js",
			"/assets/dialog-CKNSqNIz.js",
			"/assets/input-DSxCRVcD.js",
			"/assets/label-9E6XFh3F.js",
			"/assets/format-B7N2_czM.js",
			"/assets/errors-B3cbsWOO.js"
		]
	},
	"/_plant/panel": {
		filePath: "D:/Bitcycle/src/routes/_plant.panel.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.panel-DlF8UYMH.js",
			"/assets/auth-D7QxINs_.js",
			"/assets/format-B7N2_czM.js"
		]
	},
	"/_plant/recepcion": {
		filePath: "D:/Bitcycle/src/routes/_plant.recepcion.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.recepcion-B_yI3vvd.js",
			"/assets/auth-D7QxINs_.js",
			"/assets/select-cvc88EDR.js",
			"/assets/dialog-CKNSqNIz.js",
			"/assets/input-DSxCRVcD.js",
			"/assets/label-9E6XFh3F.js",
			"/assets/textarea-DMD10Bek.js",
			"/assets/format-B7N2_czM.js",
			"/assets/errors-B3cbsWOO.js",
			"/assets/ticket-card-CPdjBQRb.js"
		]
	},
	"/_plant/tiques": {
		filePath: "D:/Bitcycle/src/routes/_plant.tiques.tsx",
		children: void 0,
		preloads: [
			"/assets/_plant.tiques-Cgj3aX2P.js",
			"/assets/auth-D7QxINs_.js",
			"/assets/search-LCQ9IYRk.js",
			"/assets/dialog-CKNSqNIz.js",
			"/assets/input-DSxCRVcD.js",
			"/assets/format-B7N2_czM.js",
			"/assets/ticket-card-CPdjBQRb.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
