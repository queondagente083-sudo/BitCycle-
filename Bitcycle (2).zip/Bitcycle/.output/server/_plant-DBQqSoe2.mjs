import { g as Outlet } from "./_libs/@tanstack/react-router+[...].mjs";
import { p as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as PlantShell } from "./_ssr/plant-shell-jOF6YvpC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_plant-DBQqSoe2.js
var import_jsx_runtime = require_jsx_runtime();
function PlantLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlantShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { PlantLayout as component };
